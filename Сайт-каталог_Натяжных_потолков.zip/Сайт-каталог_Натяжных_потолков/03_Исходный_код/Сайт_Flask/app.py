from flask import Flask, render_template, request, redirect, url_for, flash, session
from flask_sqlalchemy import SQLAlchemy
from flask_login import LoginManager, UserMixin, login_user, login_required, logout_user, current_user
from werkzeug.security import generate_password_hash, check_password_hash
from werkzeug.utils import secure_filename
import os
from datetime import datetime
from functools import wraps
from sqlalchemy import and_, inspect, or_, text

app = Flask(__name__, template_folder='template')
session_secret = os.environ.get('SESSION_SECRET') or os.environ.get('SECRET_KEY')
if not session_secret:
    raise RuntimeError('Задайте SESSION_SECRET или SECRET_KEY в переменных окружения.')
app.config['SECRET_KEY'] = session_secret
app.config['SQLALCHEMY_DATABASE_URI'] = os.environ.get('DATABASE_URL', 'sqlite:///ceiling_site.db')
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
app.config['UPLOAD_FOLDER'] = os.path.join(app.root_path, 'static', 'uploads')
app.config['MAX_CONTENT_LENGTH'] = 16 * 1024 * 1024
app.config['ALLOWED_IMAGE_EXTENSIONS'] = {'jpg', 'jpeg', 'png', 'gif', 'webp'}
app.config['COMMISSION_PERCENT'] = 15
os.makedirs(app.config['UPLOAD_FOLDER'], exist_ok=True)

db = SQLAlchemy(app)
login_manager = LoginManager()
login_manager.init_app(app)
login_manager.login_view = 'login'

class User(UserMixin, db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(80), unique=True, nullable=False)
    email = db.Column(db.String(120), unique=True, nullable=False)
    password_hash = db.Column(db.String(200), nullable=False)
    role = db.Column(db.String(20), default='customer')
    is_blocked = db.Column(db.Boolean, default=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    products = db.relationship('Product', backref='seller', lazy=True)
    requests = db.relationship('Request', backref='user', lazy=True)
    reviews = db.relationship('Review', backref='author', lazy=True)

class Product(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.String(100), nullable=False)
    description = db.Column(db.Text, nullable=False)
    price = db.Column(db.Float, nullable=False)
    category = db.Column(db.String(50), nullable=False)
    material = db.Column(db.String(50), nullable=False)
    texture = db.Column(db.String(50))
    color = db.Column(db.String(30))
    size = db.Column(db.String(30))
    image_url = db.Column(db.String(200))
    seller_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    is_approved = db.Column(db.Boolean, default=False)
    requests = db.relationship('Request', backref='product', lazy=True)
    reviews = db.relationship('Review', backref='product', lazy=True, cascade='all, delete-orphan')
    purchase_requests = db.relationship('PurchaseRequest', back_populates='product', lazy=True)

class Request(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    product_id = db.Column(db.Integer, db.ForeignKey('product.id'), nullable=False)
    message = db.Column(db.Text, nullable=False)
    status = db.Column(db.String(20), default='pending')
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    admin_comment = db.Column(db.Text)

class Message(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    product_id = db.Column(db.Integer, db.ForeignKey('product.id'), nullable=False)
    sender_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    recipient_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    body = db.Column(db.Text, nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    product = db.relationship('Product', backref=db.backref('messages', lazy=True))
    sender = db.relationship('User', foreign_keys=[sender_id], backref='sent_messages')
    recipient = db.relationship('User', foreign_keys=[recipient_id], backref='received_messages')

class Review(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    product_id = db.Column(db.Integer, db.ForeignKey('product.id'), nullable=False)
    author_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    rating = db.Column(db.Integer, nullable=False)
    body = db.Column(db.Text, nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

class SupportTicket(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    subject = db.Column(db.String(160), nullable=False)
    status = db.Column(db.String(20), default='open')
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    user = db.relationship('User', backref='support_tickets')
    messages = db.relationship('SupportMessage', backref='ticket', lazy=True, cascade='all, delete-orphan', order_by='SupportMessage.created_at')

class SupportMessage(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    ticket_id = db.Column(db.Integer, db.ForeignKey('support_ticket.id'), nullable=False)
    sender_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    body = db.Column(db.Text, nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    sender = db.relationship('User', backref='support_messages')

class Balance(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False, unique=True)
    amount = db.Column(db.Float, default=0.0)
    reserved = db.Column(db.Float, default=0.0)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    user = db.relationship('User', backref='balance', lazy=True)

class Deposit(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    amount = db.Column(db.Float, nullable=False)
    status = db.Column(db.String(20), default='pending')
    payment_method = db.Column(db.String(50), default='manual')
    transaction_id = db.Column(db.String(100), unique=True)
    proof_image = db.Column(db.String(200))
    admin_comment = db.Column(db.Text)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    confirmed_at = db.Column(db.DateTime)
    user = db.relationship('User', backref='deposits', lazy=True)

class Order(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    buyer_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    seller_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    product_id = db.Column(db.Integer, db.ForeignKey('product.id'), nullable=False)
    quantity = db.Column(db.Integer, default=1)
    total_price = db.Column(db.Float, nullable=False)
    status = db.Column(db.String(30), default='payment_confirmed')
    buyer_comment = db.Column(db.Text)
    seller_comment = db.Column(db.Text)
    shipping_address = db.Column(db.Text, nullable=False)
    tracking_number = db.Column(db.String(100))
    shipping_date = db.Column(db.DateTime)
    delivered_date = db.Column(db.DateTime)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    purchase_request_id = db.Column(db.Integer, db.ForeignKey('purchase_request.id'), nullable=True)
    commission_percent = db.Column(db.Float, default=15.0)
    buyer = db.relationship('User', foreign_keys=[buyer_id], backref='orders_as_buyer')
    seller = db.relationship('User', foreign_keys=[seller_id], backref='orders_as_seller')
    product = db.relationship('Product', backref='orders', lazy=True)
    purchase_request = db.relationship('PurchaseRequest', backref='order', lazy=True)

class Transaction(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    order_id = db.Column(db.Integer, db.ForeignKey('order.id'), nullable=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    amount = db.Column(db.Float, nullable=False)
    type = db.Column(db.String(30), nullable=False)
    status = db.Column(db.String(20), default='pending')
    description = db.Column(db.Text)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    completed_at = db.Column(db.DateTime)
    order = db.relationship('Order', backref='transactions', lazy=True)
    user = db.relationship('User', backref='transactions', lazy=True)

class Withdrawal(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    amount = db.Column(db.Float, nullable=False)
    status = db.Column(db.String(20), default='pending')
    payment_details = db.Column(db.Text, nullable=False)
    admin_comment = db.Column(db.Text)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    completed_at = db.Column(db.DateTime)
    user = db.relationship('User', backref='withdrawals', lazy=True)

class PurchaseRequest(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    product_id = db.Column(db.Integer, db.ForeignKey('product.id'), nullable=False)
    buyer_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    seller_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    offered_price = db.Column(db.Float, nullable=False)
    message = db.Column(db.Text)
    status = db.Column(db.String(20), default='pending')
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    product = db.relationship('Product', back_populates='purchase_requests')
    buyer = db.relationship('User', foreign_keys=[buyer_id], backref='buyer_purchase_requests')
    seller = db.relationship('User', foreign_keys=[seller_id], backref='seller_purchase_requests')


def migrate_database():
    db.create_all()
    inspector = inspect(db.engine)
    tables = set(inspector.get_table_names())

    column_migrations = {
        'user': {
            'is_blocked': 'ALTER TABLE "user" ADD COLUMN is_blocked BOOLEAN NOT NULL DEFAULT 0',
        },
        'order': {
            'purchase_request_id': 'ALTER TABLE "order" ADD COLUMN purchase_request_id INTEGER',
            'commission_percent': 'ALTER TABLE "order" ADD COLUMN commission_percent FLOAT DEFAULT 15.0',
        },
        'purchase_request': {
            'offered_price': 'ALTER TABLE "purchase_request" ADD COLUMN offered_price FLOAT DEFAULT 0.0',
        },
    }

    for table, migrations in column_migrations.items():
        if table not in tables:
            continue
        existing_columns = {column['name'] for column in inspect(db.engine).get_columns(table)}
        for column, statement in migrations.items():
            if column not in existing_columns:
                with db.engine.begin() as connection:
                    connection.execute(text(statement))
                    if table == 'purchase_request' and column == 'offered_price':
                        connection.execute(text(
                            'UPDATE "purchase_request" '
                            'SET offered_price = ('
                            'SELECT price FROM product WHERE product.id = purchase_request.product_id'
                            ') '
                            'WHERE offered_price IS NULL OR offered_price = 0'
                        ))
                existing_columns.add(column)

    transaction_columns = {
        column['name']: column
        for column in inspect(db.engine).get_columns('transaction')
    }
    order_id_column = transaction_columns.get('order_id')
    if order_id_column and not order_id_column.get('nullable', True):
        if db.engine.dialect.name == 'sqlite':
            with db.engine.connect() as connection:
                connection.rollback()
                connection.exec_driver_sql('PRAGMA foreign_keys=OFF')
                try:
                    connection.execute(text(
                        'CREATE TABLE "transaction_new" ('
                        'id INTEGER NOT NULL PRIMARY KEY, '
                        'order_id INTEGER, '
                        'user_id INTEGER NOT NULL, '
                        'amount FLOAT NOT NULL, '
                        'type VARCHAR(30) NOT NULL, '
                        'status VARCHAR(20), '
                        'description TEXT, '
                        'created_at DATETIME, '
                        'completed_at DATETIME, '
                        'FOREIGN KEY(order_id) REFERENCES "order" (id), '
                        'FOREIGN KEY(user_id) REFERENCES "user" (id)'
                        ')'
                    ))
                    connection.execute(text(
                        'INSERT INTO "transaction_new" '
                        '(id, order_id, user_id, amount, type, status, description, created_at, completed_at) '
                        'SELECT id, order_id, user_id, amount, type, status, description, created_at, completed_at '
                        'FROM "transaction"'
                    ))
                    connection.execute(text('DROP TABLE "transaction"'))
                    connection.execute(text('ALTER TABLE "transaction_new" RENAME TO "transaction"'))
                    connection.commit()
                except Exception:
                    connection.rollback()
                    raise
                finally:
                    connection.exec_driver_sql('PRAGMA foreign_keys=ON')
        elif db.engine.dialect.name == 'postgresql':
            with db.engine.begin() as connection:
                connection.execute(text(
                    'ALTER TABLE "transaction" ALTER COLUMN order_id DROP NOT NULL'
                ))


@login_manager.user_loader
def load_user(user_id):
    return db.session.get(User, int(user_id))

def role_required(role):
    def decorator(f):
        @wraps(f)
        def decorated_function(*args, **kwargs):
            if not current_user.is_authenticated:
                flash('Пожалуйста, войдите в систему', 'error')
                return redirect(url_for('login'))
            if current_user.is_blocked:
                flash('Ваш аккаунт заблокирован', 'error')
                return redirect(url_for('logout'))
            if current_user.role != role:
                flash('У вас нет доступа к этой странице', 'error')
                return redirect(url_for('index'))
            return f(*args, **kwargs)
        return decorated_function
    return decorator

def admin_required(f):
    return role_required('admin')(f)

def seller_required(f):
    return role_required('seller')(f)

def parse_price(raw_value):
    try:
        value = float(raw_value)
    except (TypeError, ValueError):
        return None
    if value <= 0 or value > 100_000_000:
        return None
    return value


def parse_quantity(raw_value, default=1):
    try:
        quantity = int(raw_value)
    except (TypeError, ValueError):
        return default
    return max(0, min(quantity, 100))


def save_image(image_file):
    if not image_file or not image_file.filename:
        return None
    filename = secure_filename(image_file.filename)
    if not filename or '.' not in filename:
        return None
    extension = filename.rsplit('.', 1)[1].lower()
    if extension not in app.config['ALLOWED_IMAGE_EXTENSIONS']:
        return None
    timestamp = datetime.now().strftime('%Y%m%d_%H%M%S_%f_')
    stored_name = timestamp + filename
    image_file.save(os.path.join(app.config['UPLOAD_FOLDER'], stored_name))
    return 'uploads/' + stored_name

def get_balance(user_id):
    balance = Balance.query.filter_by(user_id=user_id).first()
    if not balance:
        balance = Balance(user_id=user_id, amount=0.0, reserved=0.0)
        db.session.add(balance)
        db.session.commit()
    return balance

def get_available_balance(user_id):
    balance = get_balance(user_id)
    return balance.amount - balance.reserved

def reserve_funds(user_id, amount):
    balance = get_balance(user_id)
    if balance.amount - balance.reserved < amount:
        return False
    balance.reserved += amount
    db.session.commit()
    return True

def release_funds(user_id, amount):
    balance = get_balance(user_id)
    balance.reserved -= amount
    balance.amount -= amount
    db.session.commit()
    return True

def add_funds(user_id, amount, description="", order_id=None, transaction_type='deposit'):
    balance = get_balance(user_id)
    balance.amount += amount
    db.session.commit()
    transaction = Transaction(
        order_id=order_id,
        user_id=user_id,
        amount=amount,
        type=transaction_type,
        status='completed',
        description=description,
    )
    db.session.add(transaction)
    db.session.commit()
    return True

def refund_order(order):
    buyer = order.buyer
    balance = get_balance(buyer.id)
    balance.amount += order.total_price
    balance.reserved -= order.total_price
    db.session.commit()
    transaction = Transaction(order_id=order.id, user_id=buyer.id, amount=order.total_price, type='refund', status='completed', description=f'Возврат по заказу #{order.id}')
    db.session.add(transaction)
    order.status = 'refunded'
    db.session.commit()
    return True

def complete_order(order):
    seller = order.seller
    commission_percent = order.commission_percent or app.config['COMMISSION_PERCENT']
    commission = order.total_price * commission_percent / 100
    amount_to_seller = order.total_price - commission
    add_funds(
        seller.id,
        amount_to_seller,
        f'Оплата заказа #{order.id} (комиссия {commission:.2f} ₽)',
        order_id=order.id,
        transaction_type='seller_payout',
    )
    transaction = Transaction.query.filter_by(order_id=order.id, type='hold').first()
    if transaction:
        release_funds(order.buyer_id, order.total_price)
        transaction.status = 'released'
    order.status = 'completed'
    db.session.commit()
    return True

@app.route('/')
def index():
    products = Product.query.filter_by(is_approved=True).all()
    return render_template('index.html', products=products)

@app.route('/products')
def products():
    category = request.args.get('category')
    material = request.args.get('material')
    query = Product.query.filter_by(is_approved=True)
    if category:
        query = query.filter_by(category=category)
    if material:
        query = query.filter_by(material=material)
    products = query.all()
    categories = db.session.query(Product.category).distinct().all()
    materials = db.session.query(Product.material).distinct().all()
    return render_template('products.html', products=products, categories=categories, materials=materials)

@app.route('/product/<int:product_id>')
def product_detail(product_id):
    product = db.session.get(Product, product_id)
    if product is None:
        flash('Товар не найден', 'error')
        return redirect(url_for('products'))
    can_view_unapproved = (current_user.is_authenticated and (current_user.role == 'admin' or product.seller_id == current_user.id))
    if not product.is_approved and not can_view_unapproved:
        flash('Этот товар ещё проходит модерацию', 'warning')
        return redirect(url_for('products'))
    reviews = Review.query.filter_by(product_id=product.id).order_by(Review.created_at.desc()).all()
    average_rating = round(sum(review.rating for review in reviews) / len(reviews), 1) if reviews else 0
    return render_template('product_detail.html', product=product, reviews=reviews, average_rating=average_rating)

@app.route('/messages')
@login_required
def messages():
    if current_user.role == 'admin':
        return redirect(url_for('admin_support'))
    query = Message.query.filter(or_(Message.sender_id == current_user.id, Message.recipient_id == current_user.id)).order_by(Message.created_at.desc())
    all_messages = query.all()
    threads = {}
    for message in all_messages:
        other_id = message.recipient_id if message.sender_id == current_user.id else message.sender_id
        key = (message.product_id, other_id)
        if key not in threads:
            threads[key] = message
    return render_template('messages.html', threads=list(threads.values()))

@app.route('/messages/<int:product_id>/<int:user_id>', methods=['GET', 'POST'])
@login_required
def chat(product_id, user_id):
    product = db.session.get(Product, product_id)
    other_user = db.session.get(User, user_id)
    if product is None or other_user is None:
        flash('Диалог не найден', 'error')
        return redirect(url_for('messages'))
    is_product_seller = current_user.id == product.seller_id and other_user.role == 'customer'
    is_product_buyer = current_user.role == 'customer' and current_user.id != product.seller_id and other_user.id == product.seller_id
    if not (is_product_seller or is_product_buyer):
        flash('У вас нет доступа к этому диалогу', 'error')
        return redirect(url_for('messages'))
    if other_user.id == current_user.id:
        flash('Некорректный участник диалога', 'error')
        return redirect(url_for('messages'))
    if request.method == 'POST':
        body = request.form.get('body', '').strip()
        if body:
            db.session.add(Message(product_id=product.id, sender_id=current_user.id, recipient_id=other_user.id, body=body))
            db.session.commit()
            return redirect(url_for('chat', product_id=product.id, user_id=user_id))
        flash('Введите сообщение', 'error')
    conversation = Message.query.filter(Message.product_id == product.id, or_(and_(Message.sender_id == current_user.id, Message.recipient_id == other_user.id), and_(Message.sender_id == other_user.id, Message.recipient_id == current_user.id))).order_by(Message.created_at.asc()).all()
    return render_template('chat.html', product=product, other_user=other_user, conversation=conversation)

@app.route('/chat/offer/<int:product_id>/<int:user_id>', methods=['POST'])
@login_required
def send_offer(product_id, user_id):
    product = db.session.get(Product, product_id)
    buyer = db.session.get(User, user_id)
    if product is None or buyer is None:
        flash('Некорректные данные', 'error')
        return redirect(url_for('messages'))
    if current_user.id != product.seller_id:
        flash('Только продавец может отправлять предложение', 'error')
        return redirect(url_for('chat', product_id=product.id, user_id=user_id))
    if buyer.role != 'customer':
        flash('Предложение можно отправить только покупателю', 'error')
        return redirect(url_for('chat', product_id=product.id, user_id=user_id))
    offered_price = parse_price(request.form.get('offered_price'))
    if offered_price is None or offered_price <= 0:
        flash('Укажите корректную цену', 'error')
        return redirect(url_for('chat', product_id=product.id, user_id=user_id))
    message = request.form.get('offer_message', '').strip()
    existing = PurchaseRequest.query.filter(
        PurchaseRequest.product_id == product.id,
        PurchaseRequest.buyer_id == buyer.id,
        PurchaseRequest.status.in_(['pending', 'admin_approved']),
    ).first()
    if existing:
        flash('У вас уже есть активное предложение по этому товару', 'warning')
        return redirect(url_for('chat', product_id=product.id, user_id=user_id))
    pr = PurchaseRequest(
        product_id=product.id,
        buyer_id=buyer.id,
        seller_id=current_user.id,
        offered_price=offered_price,
        message=message,
        status='pending'
    )
    db.session.add(pr)
    db.session.commit()
    flash('Предложение отправлено на модерацию администратору', 'success')
    return redirect(url_for('chat', product_id=product.id, user_id=user_id))

@app.route('/my_offers')
@login_required
def my_offers():
    if current_user.role != 'customer':
        flash('Доступно только для покупателей', 'error')
        return redirect(url_for('index'))
    offers = PurchaseRequest.query.filter_by(buyer_id=current_user.id).order_by(PurchaseRequest.created_at.desc()).all()
    return render_template('my_offers.html', offers=offers)

@app.route('/offer/<int:offer_id>')
@login_required
def offer_detail(offer_id):
    offer = db.session.get(PurchaseRequest, offer_id)
    if not offer or (offer.buyer_id != current_user.id and offer.seller_id != current_user.id and current_user.role != 'admin'):
        flash('Доступ запрещён', 'error')
        return redirect(url_for('index'))
    return render_template('offer_detail.html', offer=offer)

@app.route('/offer/<int:offer_id>/pay', methods=['POST'])
@login_required
def pay_offer(offer_id):
    offer = db.session.get(PurchaseRequest, offer_id)
    if not offer or offer.buyer_id != current_user.id:
        flash('Доступ запрещён', 'error')
        return redirect(url_for('index'))
    if offer.status != 'admin_approved':
        flash('Это предложение ещё не одобрено администратором', 'warning')
        return redirect(url_for('offer_detail', offer_id=offer.id))
    total = offer.offered_price
    if get_available_balance(current_user.id) < total:
        flash(f'Недостаточно средств. Пополните баланс. Нужно: {total:.2f} ₽', 'error')
        return redirect(url_for('offer_detail', offer_id=offer.id))
    if not reserve_funds(current_user.id, total):
        flash('Ошибка резервирования средств', 'error')
        return redirect(url_for('offer_detail', offer_id=offer.id))
    order = Order(
        buyer_id=offer.buyer_id,
        seller_id=offer.seller_id,
        product_id=offer.product_id,
        quantity=1,
        total_price=total,
        status='payment_confirmed',
        shipping_address='',
        purchase_request_id=offer.id,
        commission_percent=app.config['COMMISSION_PERCENT']
    )
    db.session.add(order)
    db.session.flush()
    transaction = Transaction(order_id=order.id, user_id=current_user.id, amount=total, type='hold', status='completed', description=f'Блокировка средств для заказа #{order.id}')
    db.session.add(transaction)
    offer.status = 'paid'
    db.session.commit()
    flash(f'Заказ #{order.id} создан! Средства заблокированы.', 'success')
    return redirect(url_for('order_detail', order_id=order.id))

@app.route('/admin/offers')
@login_required
@admin_required
def admin_offers():
    offers = PurchaseRequest.query.order_by(PurchaseRequest.created_at.desc()).all()
    return render_template('admin_offers.html', offers=offers)

@app.route('/admin/offer/<int:offer_id>/<action>', methods=['POST'])
@login_required
@admin_required
def admin_handle_offer(offer_id, action):
    offer = db.session.get(PurchaseRequest, offer_id)
    if not offer:
        flash('Предложение не найдено', 'error')
        return redirect(url_for('admin_offers'))
    if offer.status != 'pending':
        flash('Это предложение уже обработано', 'warning')
        return redirect(url_for('admin_offers'))
    if action == 'approve':
        offer.status = 'admin_approved'
        flash('Предложение одобрено, покупатель может оплатить', 'success')
    elif action == 'reject':
        offer.status = 'cancelled'
        flash('Предложение отклонено', 'warning')
    else:
        flash('Неизвестное действие', 'error')
    db.session.commit()
    return redirect(url_for('admin_offers'))

@app.route('/admin/order/<int:order_id>/refund', methods=['POST'])
@login_required
@admin_required
def admin_refund_order(order_id):
    order = db.session.get(Order, order_id)
    if not order:
        flash('Заказ не найден', 'error')
        return redirect(url_for('admin_orders'))
    if order.status in ('completed', 'refunded'):
        flash('Невозможно вернуть деньги', 'warning')
        return redirect(url_for('admin_orders'))
    refund_order(order)
    flash(f'Деньги по заказу #{order.id} возвращены покупателю', 'success')
    return redirect(url_for('admin_orders'))

@app.route('/admin/user/<int:user_id>/block', methods=['POST'])
@login_required
@admin_required
def block_user(user_id):
    user = db.session.get(User, user_id)
    if not user:
        flash('Пользователь не найден', 'error')
        return redirect(url_for('admin_users'))
    if user.id == current_user.id:
        flash('Нельзя заблокировать самого себя', 'error')
        return redirect(url_for('admin_users'))
    user.is_blocked = not user.is_blocked
    db.session.commit()
    status = 'заблокирован' if user.is_blocked else 'разблокирован'
    flash(f'Пользователь {user.username} {status}', 'success')
    return redirect(url_for('admin_users'))

@app.route('/support', methods=['GET', 'POST'])
@login_required
def support():
    if current_user.role == 'admin':
        return redirect(url_for('admin_support'))
    if request.method == 'POST':
        subject = request.form.get('subject', '').strip()
        body = request.form.get('body', '').strip()
        if not subject or not body:
            flash('Заполните тему и сообщение', 'error')
        else:
            ticket = SupportTicket(user_id=current_user.id, subject=subject)
            db.session.add(ticket)
            db.session.flush()
            db.session.add(SupportMessage(ticket_id=ticket.id, sender_id=current_user.id, body=body))
            db.session.commit()
            flash('Обращение отправлено в техподдержку', 'success')
            return redirect(url_for('support'))
    tickets = SupportTicket.query.filter_by(user_id=current_user.id).order_by(SupportTicket.updated_at.desc()).all()
    return render_template('support.html', tickets=tickets)

@app.route('/support/<int:ticket_id>', methods=['GET', 'POST'])
@login_required
def support_ticket(ticket_id):
    ticket = db.session.get(SupportTicket, ticket_id)
    if ticket is None or (ticket.user_id != current_user.id and current_user.role != 'admin'):
        flash('Обращение не найдено', 'error')
        return redirect(url_for('support'))
    if request.method == 'POST':
        body = request.form.get('body', '').strip()
        if body:
            db.session.add(SupportMessage(ticket_id=ticket.id, sender_id=current_user.id, body=body))
            if current_user.role == 'admin':
                ticket.status = 'answered'
            else:
                ticket.status = 'open'
            ticket.updated_at = datetime.utcnow()
            db.session.commit()
            flash('Сообщение добавлено', 'success')
            return redirect(url_for('support_ticket', ticket_id=ticket.id))
        flash('Введите сообщение', 'error')
    return render_template('support_ticket.html', ticket=ticket, is_admin=current_user.role == 'admin')

@app.route('/admin/support')
@login_required
@admin_required
def admin_support():
    tickets = SupportTicket.query.order_by(SupportTicket.updated_at.desc()).all()
    return render_template('admin_support.html', tickets=tickets)

@app.route('/product/<int:product_id>/review', methods=['POST'])
@login_required
def add_review(product_id):
    if current_user.role != 'customer':
        flash('Отзывы могут оставлять только покупатели', 'error')
        return redirect(url_for('product_detail', product_id=product_id))
    product = db.session.get(Product, product_id)
    if product is None:
        flash('Товар не найден', 'error')
        return redirect(url_for('products'))
    if not product.is_approved:
        flash('Нельзя оставить отзыв на товар, который не опубликован', 'warning')
        return redirect(url_for('product_detail', product_id=product.id))
    try:
        rating = int(request.form.get('rating', '0'))
    except ValueError:
        rating = 0
    body = request.form.get('body', '').strip()
    if rating < 1 or rating > 5 or not body:
        flash('Выберите оценку от 1 до 5 и напишите отзыв', 'error')
    elif Review.query.filter_by(product_id=product.id, author_id=current_user.id).first():
        flash('Вы уже оставляли отзыв на этот товар', 'warning')
    else:
        db.session.add(Review(product_id=product.id, author_id=current_user.id, rating=rating, body=body))
        db.session.commit()
        flash('Спасибо за отзыв!', 'success')
    return redirect(url_for('product_detail', product_id=product.id))

@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        username = request.form['username']
        email = request.form['email']
        password = request.form['password']
        password_confirm = request.form.get('password_confirm')
        role = request.form.get('role', 'customer')
        if role not in {'customer', 'seller'}:
            role = 'customer'
        if password != password_confirm:
            flash('Пароли не совпадают!', 'error')
            return redirect(url_for('register'))
        if User.query.filter_by(username=username).first():
            flash('Имя пользователя уже занято', 'error')
            return redirect(url_for('register'))
        if User.query.filter_by(email=email).first():
            flash('Email уже используется', 'error')
            return redirect(url_for('register'))
        hashed_password = generate_password_hash(password, method='pbkdf2:sha256')
        user = User(username=username, email=email, password_hash=hashed_password, role=role)
        db.session.add(user)
        db.session.commit()
        flash('Регистрация успешна! Войдите в систему.', 'success')
        return redirect(url_for('login'))
    return render_template('register.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        user = User.query.filter_by(username=username).first()
        if user and check_password_hash(user.password_hash, password):
            if user.is_blocked:
                flash('Ваш аккаунт заблокирован', 'error')
                return redirect(url_for('login'))
            login_user(user)
            flash(f'Добро пожаловать, {user.username}!', 'success')
            if user.role == 'admin':
                return redirect(url_for('admin_panel'))
            elif user.role == 'seller':
                return redirect(url_for('seller_dashboard'))
            else:
                return redirect(url_for('index'))
        else:
            flash('Неверное имя пользователя или пароль', 'error')
    return render_template('login.html')

@app.route('/logout')
@login_required
def logout():
    logout_user()
    flash('Вы вышли из системы', 'info')
    return redirect(url_for('index'))

@app.route('/seller/dashboard')
@login_required
@seller_required
def seller_dashboard():
    products = Product.query.filter_by(seller_id=current_user.id).all()
    pending_offers = PurchaseRequest.query.filter_by(seller_id=current_user.id, status='pending').count()
    return render_template('dashboard.html', products=products, pending_offers=pending_offers)

@app.route('/seller/add_product', methods=['GET', 'POST'])
@login_required
@seller_required
def add_product():
    if request.method == 'POST':
        title = request.form['title']
        description = request.form['description']
        price = parse_price(request.form.get('price'))
        if price is None:
            flash('Укажите корректную положительную цену', 'error')
            return redirect(url_for('add_product'))
        category = request.form['category']
        material = request.form['material']
        texture = request.form.get('texture')
        color = request.form.get('color')
        size = request.form.get('size')
        image_file = request.files.get('image')
        image_url = None
        if image_file and image_file.filename:
            image_url = save_image(image_file)
            if image_url is None:
                flash('Поддерживаются только JPG, PNG, GIF и WEBP', 'error')
                return redirect(url_for('add_product'))
        product = Product(title=title, description=description, price=price, category=category, material=material, texture=texture, color=color, size=size, image_url=image_url, seller_id=current_user.id, is_approved=False)
        db.session.add(product)
        db.session.commit()
        flash('Товар добавлен и ожидает одобрения администратора', 'success')
        return redirect(url_for('seller_dashboard'))
    return render_template('add_product.html')

@app.route('/seller/edit_product/<int:product_id>', methods=['GET', 'POST'])
@login_required
@seller_required
def edit_product(product_id):
    product = db.session.get(Product, product_id)
    if product is None:
        flash('Товар не найден', 'error')
        return redirect(url_for('seller_dashboard'))
    if product.seller_id != current_user.id:
        flash('У вас нет прав на редактирование этого товара', 'error')
        return redirect(url_for('seller_dashboard'))
    if request.method == 'POST':
        product.title = request.form['title']
        product.description = request.form['description']
        price = parse_price(request.form.get('price'))
        if price is None:
            flash('Укажите корректную положительную цену', 'error')
            return redirect(url_for('edit_product', product_id=product.id))
        product.price = price
        product.category = request.form['category']
        product.material = request.form['material']
        product.texture = request.form.get('texture')
        product.color = request.form.get('color')
        product.size = request.form.get('size')
        image_file = request.files.get('image')
        if image_file and image_file.filename:
            new_image_url = save_image(image_file)
            if new_image_url is None:
                flash('Поддерживаются только JPG, PNG, GIF и WEBP', 'error')
                return redirect(url_for('edit_product', product_id=product.id))
            if product.image_url:
                try:
                    os.remove(os.path.join(app.config['UPLOAD_FOLDER'], os.path.basename(product.image_url)))
                except OSError:
                    pass
            product.image_url = new_image_url
        product.is_approved = False
        db.session.commit()
        flash('Товар обновлен и отправлен на повторную модерацию', 'success')
        return redirect(url_for('seller_dashboard'))
    return render_template('edit_product.html', product=product)

@app.route('/seller/delete_product/<int:product_id>', methods=['POST'])
@login_required
@seller_required
def delete_product(product_id):
    product = db.session.get(Product, product_id)
    if product is None:
        flash('Товар не найден', 'error')
        return redirect(url_for('seller_dashboard'))
    if product.seller_id != current_user.id:
        flash('У вас нет прав на удаление этого товара', 'error')
        return redirect(url_for('seller_dashboard'))
    if product.image_url:
        try:
            os.remove(os.path.join(app.config['UPLOAD_FOLDER'], os.path.basename(product.image_url)))
        except Exception:
            pass
    db.session.delete(product)
    db.session.commit()
    flash('Товар удален', 'success')
    return redirect(url_for('seller_dashboard'))

@app.route('/request_product/<int:product_id>', methods=['GET', 'POST'])
@login_required
def request_product(product_id):
    if current_user.role != 'customer':
        flash('Запросы на товары доступны только покупателям', 'error')
        return redirect(url_for('product_detail', product_id=product_id))
    product = db.session.get(Product, product_id)
    if product is None:
        flash('Товар не найден', 'error')
        return redirect(url_for('products'))
    if request.method == 'POST':
        message = request.form.get('message', '').strip()
        if not message:
            flash('Введите сообщение', 'error')
            return render_template('request_product.html', product=product)
        req = Request(user_id=current_user.id, product_id=product_id, message=message)
        db.session.add(req)
        db.session.commit()
        flash('Запрос отправлен', 'success')
        return redirect(url_for('product_detail', product_id=product_id))
    return render_template('request_product.html', product=product)

@app.route('/admin')
@login_required
@admin_required
def admin_panel():
    products_count = Product.query.count()
    users_count = User.query.count()
    requests_count = Request.query.count()
    pending_products = Product.query.filter_by(is_approved=False).count()
    approved_products = Product.query.filter_by(is_approved=True).count()
    admin_count = User.query.filter_by(role='admin').count()
    seller_count = User.query.filter_by(role='seller').count()
    customer_count = User.query.filter_by(role='customer').count()
    pending_requests = Request.query.filter_by(status='pending').count()
    approved_requests = Request.query.filter_by(status='approved').count()
    rejected_requests = Request.query.filter_by(status='rejected').count()
    latest_product = Product.query.order_by(Product.created_at.desc()).first()
    latest_user = User.query.order_by(User.created_at.desc()).first()
    latest_request = Request.query.order_by(Request.created_at.desc()).first()
    support_count = SupportTicket.query.filter_by(status='open').count()
    pending_offers = PurchaseRequest.query.filter_by(status='pending').count()
    return render_template('admin_panel.html',
                           products_count=products_count,
                           users_count=users_count,
                           requests_count=requests_count,
                           pending_products=pending_products,
                           approved_products=approved_products,
                           admin_count=admin_count,
                           seller_count=seller_count,
                           customer_count=customer_count,
                           pending_requests=pending_requests,
                           approved_requests=approved_requests,
                           rejected_requests=rejected_requests,
                           latest_product=latest_product,
                           latest_user=latest_user,
                           latest_request=latest_request,
                           support_count=support_count,
                           pending_offers=pending_offers)

@app.route('/admin/products')
@login_required
@admin_required
def admin_products():
    products = Product.query.all()
    return render_template('admin_products.html', products=products)

@app.route('/admin/approve_product/<int:product_id>', methods=['POST'])
@login_required
@admin_required
def approve_product(product_id):
    product = db.session.get(Product, product_id)
    if product is None:
        flash('Товар не найден', 'error')
        return redirect(url_for('admin_products'))
    product.is_approved = True
    db.session.commit()
    flash('Товар одобрен', 'success')
    return redirect(url_for('admin_products'))

@app.route('/admin/reject_product/<int:product_id>', methods=['POST'])
@login_required
@admin_required
def reject_product(product_id):
    product = db.session.get(Product, product_id)
    if product is None:
        flash('Товар не найден', 'error')
        return redirect(url_for('admin_products'))
    product.is_approved = False
    db.session.commit()
    flash('Товар отклонен', 'warning')
    return redirect(url_for('admin_products'))

@app.route('/admin/requests')
@login_required
@admin_required
def admin_requests():
    requests = Request.query.all()
    return render_template('admin_requests.html', requests=requests)

@app.route('/admin/request/<int:request_id>/<action>', methods=['POST'])
@login_required
@admin_required
def handle_request(request_id, action):
    req = db.session.get(Request, request_id)
    if req is None:
        flash('Запрос не найден', 'error')
        return redirect(url_for('admin_requests'))
    if action == 'approve':
        req.status = 'approved'
        flash('Запрос одобрен', 'success')
    elif action == 'reject':
        req.status = 'rejected'
        flash('Запрос отклонен', 'warning')
    else:
        flash('Неизвестное действие', 'error')
        return redirect(url_for('admin_requests'))
    db.session.commit()
    return redirect(url_for('admin_requests'))

@app.route('/admin/users')
@login_required
@admin_required
def admin_users():
    users = User.query.all()
    return render_template('admin_users.html', users=users)

@app.route('/admin/change_user_role/<int:user_id>', methods=['POST'])
@login_required
@admin_required
def change_user_role(user_id):
    user = db.session.get(User, user_id)
    if user is None:
        flash('Пользователь не найден', 'error')
        return redirect(url_for('admin_users'))
    if user.id == current_user.id:
        flash('Нельзя изменить свою роль', 'error')
        return redirect(url_for('admin_users'))
    new_role = request.form.get('role')
    if new_role not in {'customer', 'seller', 'admin'}:
        flash('Недопустимая роль', 'error')
        return redirect(url_for('admin_users'))
    user.role = new_role
    db.session.commit()
    flash(f'Роль пользователя {user.username} изменена на {new_role}', 'success')
    return redirect(url_for('admin_users'))

@app.route('/cart')
def cart():
    raw_cart = session.get('cart', {})
    cart_items = {}
    if isinstance(raw_cart, dict):
        for product_id, raw_quantity in raw_cart.items():
            try:
                normalized_id = int(product_id)
            except (TypeError, ValueError):
                continue
            quantity = parse_quantity(raw_quantity)
            if normalized_id > 0 and quantity > 0:
                cart_items[str(normalized_id)] = quantity
    if cart_items != raw_cart:
        session['cart'] = cart_items
        session.modified = True
    products_data = []
    total = 0
    for product_id, quantity in cart_items.items():
        product = db.session.get(Product, int(product_id))
        if product and product.is_approved:
            products_data.append({'product': product, 'quantity': quantity, 'subtotal': product.price * quantity})
            total += product.price * quantity
    return render_template('cart.html', products=products_data, total=total)

@app.route('/cart/add/<int:product_id>', methods=['POST'])
def add_to_cart(product_id):
    product = db.session.get(Product, product_id)
    if not product or not product.is_approved:
        flash('Товар не найден или не опубликован', 'error')
        return redirect(url_for('products'))
    if 'cart' not in session:
        session['cart'] = {}
    quantity = parse_quantity(request.form.get('quantity', 1))
    if quantity < 1:
        quantity = 1
    cart = session.get('cart', {})
    if not isinstance(cart, dict):
        cart = {}
    current_quantity = parse_quantity(cart.get(str(product_id)), default=0)
    cart[str(product_id)] = min(100, current_quantity + quantity)
    session['cart'] = cart
    session.modified = True
    flash(f'Товар "{product.title}" добавлен в корзину', 'success')
    return redirect(url_for('cart'))

@app.route('/cart/remove/<int:product_id>', methods=['POST'])
def remove_from_cart(product_id):
    cart = session.get('cart', {})
    cart.pop(str(product_id), None)
    session['cart'] = cart
    session.modified = True
    flash('Товар удалён из корзины', 'success')
    return redirect(url_for('cart'))

@app.route('/cart/update/<int:product_id>', methods=['POST'])
def update_cart(product_id):
    quantity = parse_quantity(request.form.get('quantity', 1))
    cart = session.get('cart', {})
    if quantity <= 0:
        cart.pop(str(product_id), None)
    else:
        cart[str(product_id)] = quantity
    session['cart'] = cart
    session.modified = True
    return redirect(url_for('cart'))

@app.route('/checkout', methods=['GET', 'POST'])
@login_required
def checkout():
    if current_user.role != 'customer':
        flash('Заказы могут оформлять только покупатели', 'error')
        return redirect(url_for('index'))
    raw_cart = session.get('cart', {})
    cart_items = {}
    if isinstance(raw_cart, dict):
        for product_id, raw_quantity in raw_cart.items():
            try:
                normalized_id = int(product_id)
            except (TypeError, ValueError):
                continue
            quantity = parse_quantity(raw_quantity)
            if normalized_id > 0 and quantity > 0:
                cart_items[str(normalized_id)] = quantity
    if not cart_items:
        flash('Корзина пуста', 'error')
        return redirect(url_for('cart'))
    products_data = []
    total = 0
    sellers = set()
    for product_id, quantity in cart_items.items():
        product = db.session.get(Product, int(product_id))
        if product and product.is_approved:
            products_data.append({'product': product, 'quantity': quantity, 'subtotal': product.price * quantity})
            total += product.price * quantity
            sellers.add(product.seller_id)
    if not products_data:
        session.pop('cart', None)
        session.modified = True
        flash('В корзине нет доступных опубликованных товаров', 'error')
        return redirect(url_for('cart'))
    if len(sellers) > 1:
        flash('В корзине товары от разных продавцов. Оформляйте заказы по отдельности.', 'error')
        return redirect(url_for('cart'))
    if request.method == 'POST':
        shipping_address = request.form.get('shipping_address', '').strip()
        if not shipping_address:
            flash('Укажите адрес доставки', 'error')
            return render_template('checkout.html', products=products_data, total=total)
        balance = get_balance(current_user.id)
        if balance.amount - balance.reserved < total:
            flash(f'Недостаточно средств на счету. Пополните баланс. Нужно: {total:.2f} ₽', 'error')
            return render_template('checkout.html', products=products_data, total=total)
        if not reserve_funds(current_user.id, total):
            flash('Ошибка резервирования средств', 'error')
            return render_template('checkout.html', products=products_data, total=total)
        orders = []
        try:
            for item in products_data:
                order = Order(
                    buyer_id=current_user.id,
                    seller_id=item['product'].seller_id,
                    product_id=item['product'].id,
                    quantity=item['quantity'],
                    total_price=item['subtotal'],
                    status='payment_confirmed',
                    shipping_address=shipping_address,
                    buyer_comment=request.form.get('comment', '').strip(),
                    commission_percent=app.config['COMMISSION_PERCENT'],
                )
                db.session.add(order)
                db.session.flush()
                db.session.add(Transaction(
                    order_id=order.id,
                    user_id=current_user.id,
                    amount=item['subtotal'],
                    type='hold',
                    status='completed',
                    description=f'Блокировка средств для заказа #{order.id}',
                ))
                orders.append(order)
            db.session.commit()
        except Exception:
            db.session.rollback()
            balance = get_balance(current_user.id)
            balance.reserved = max(0, balance.reserved - total)
            db.session.commit()
            flash('Не удалось оформить заказ. Попробуйте ещё раз.', 'error')
            return render_template('checkout.html', products=products_data, total=total)
        session.pop('cart', None)
        session.modified = True
        if len(orders) == 1:
            flash(f'Заказ #{orders[0].id} оформлен! Средства заблокированы.', 'success')
        else:
            order_numbers = ', '.join(f'#{order.id}' for order in orders)
            flash(f'Заказы {order_numbers} оформлены! Средства заблокированы.', 'success')
        return redirect(url_for('order_detail', order_id=orders[0].id))
    return render_template('checkout.html', products=products_data, total=total)

@app.route('/orders')
@login_required
def orders():
    if current_user.role == 'customer':
        orders = Order.query.filter_by(buyer_id=current_user.id).order_by(Order.created_at.desc()).all()
    elif current_user.role == 'seller':
        orders = Order.query.filter_by(seller_id=current_user.id).order_by(Order.created_at.desc()).all()
    else:
        orders = Order.query.order_by(Order.created_at.desc()).all()
    return render_template('orders.html', orders=orders)

@app.route('/orders/<int:order_id>')
@login_required
def order_detail(order_id):
    order = db.session.get(Order, order_id)
    if not order:
        flash('Заказ не найден', 'error')
        return redirect(url_for('orders'))
    if current_user.role != 'admin' and current_user.id not in [order.buyer_id, order.seller_id]:
        flash('У вас нет доступа к этому заказу', 'error')
        return redirect(url_for('orders'))
    return render_template('order_detail.html', order=order)

@app.route('/orders/<int:order_id>/shipping', methods=['POST'])
@login_required
def update_shipping(order_id):
    order = db.session.get(Order, order_id)
    if not order or order.seller_id != current_user.id:
        flash('У вас нет прав на это действие', 'error')
        return redirect(url_for('orders'))
    if order.status != 'payment_confirmed':
        flash('Неверный статус заказа', 'error')
        return redirect(url_for('order_detail', order_id=order.id))
    tracking_number = request.form.get('tracking_number', '').strip()
    if not tracking_number:
        flash('Укажите трек-номер', 'error')
        return redirect(url_for('order_detail', order_id=order.id))
    order.status = 'shipped'
    order.tracking_number = tracking_number
    order.shipping_date = datetime.utcnow()
    db.session.commit()
    flash('Статус отгрузки обновлён!', 'success')
    return redirect(url_for('order_detail', order_id=order.id))

@app.route('/orders/<int:order_id>/delivered', methods=['POST'])
@login_required
def confirm_delivery(order_id):
    order = db.session.get(Order, order_id)
    if not order or order.buyer_id != current_user.id:
        flash('У вас нет прав на это действие', 'error')
        return redirect(url_for('orders'))
    if order.status != 'shipped':
        flash('Неверный статус заказа', 'error')
        return redirect(url_for('order_detail', order_id=order.id))
    order.status = 'delivered'
    order.delivered_date = datetime.utcnow()
    db.session.commit()
    flash('Вы подтвердили получение товара!', 'success')
    return redirect(url_for('order_detail', order_id=order.id))

@app.route('/admin/orders')
@login_required
@admin_required
def admin_orders():
    orders = Order.query.order_by(Order.created_at.desc()).all()
    return render_template('admin_orders.html', orders=orders)

@app.route('/admin/orders/<int:order_id>/complete', methods=['POST'])
@login_required
@admin_required
def complete_order_admin(order_id):
    order = db.session.get(Order, order_id)
    if not order or order.status != 'delivered':
        flash('Заказ не может быть завершён', 'error')
        return redirect(url_for('admin_orders'))
    complete_order(order)
    flash(f'Заказ #{order.id} завершён! Деньги переведены продавцу за вычетом комиссии.', 'success')
    return redirect(url_for('admin_orders'))

@app.route('/balance')
@login_required
def balance():
    balance = get_balance(current_user.id)
    deposits = Deposit.query.filter_by(user_id=current_user.id).order_by(Deposit.created_at.desc()).all()
    transactions = Transaction.query.filter_by(user_id=current_user.id).order_by(Transaction.created_at.desc()).limit(20).all()
    return render_template('balance.html', balance=balance, deposits=deposits, transactions=transactions)

@app.route('/balance/deposit', methods=['GET', 'POST'])
@login_required
def deposit():
    if request.method == 'POST':
        amount = parse_price(request.form.get('amount'))
        if amount is None or amount < 100:
            flash('Минимальная сумма пополнения: 100 ₽', 'error')
            return render_template('deposit.html')
        proof_image = request.files.get('proof_image')
        proof_url = None
        if proof_image and proof_image.filename:
            proof_url = save_image(proof_image)
            if not proof_url:
                flash('Ошибка загрузки изображения', 'error')
                return render_template('deposit.html')
        deposit = Deposit(
            user_id=current_user.id,
            amount=amount,
            status='pending',
            payment_method='manual',
            transaction_id=f'DEP-{datetime.now().strftime("%Y%m%d%H%M%S%f")}-{current_user.id}',
            proof_image=proof_url,
        )
        db.session.add(deposit)
        db.session.commit()
        flash(f'Заявка на пополнение #{deposit.id} создана. Ожидайте проверки администратором.', 'success')
        return redirect(url_for('balance'))
    return render_template('deposit.html')

@app.route('/balance/withdraw', methods=['GET', 'POST'])
@login_required
def withdraw():
    if request.method == 'POST':
        amount = parse_price(request.form.get('amount'))
        if amount is None or amount < 100:
            flash('Минимальная сумма вывода: 100 ₽', 'error')
            return render_template('withdraw.html')
        balance = get_balance(current_user.id)
        available = balance.amount - balance.reserved
        if amount > available:
            flash(f'Недостаточно средств. Доступно: {available:.2f} ₽', 'error')
            return render_template('withdraw.html')
        payment_details = request.form.get('payment_details', '').strip()
        if not payment_details:
            flash('Укажите реквизиты для вывода', 'error')
            return render_template('withdraw.html')
        withdrawal = Withdrawal(user_id=current_user.id, amount=amount, status='pending', payment_details=payment_details)
        db.session.add(withdrawal)
        db.session.commit()
        flash('Заявка на вывод отправлена', 'success')
        return redirect(url_for('balance'))
    return render_template('withdraw.html')

@app.route('/admin/deposits')
@login_required
@admin_required
def admin_deposits():
    deposits = Deposit.query.order_by(Deposit.created_at.desc()).all()
    return render_template('admin_deposits.html', deposits=deposits)

@app.route('/admin/deposits/<int:deposit_id>/<action>', methods=['POST'])
@login_required
@admin_required
def handle_deposit(deposit_id, action):
    deposit = db.session.get(Deposit, deposit_id)
    if not deposit:
        flash('Заявка не найдена', 'error')
        return redirect(url_for('admin_deposits'))
    if deposit.status != 'pending':
        flash('Заявка уже обработана', 'warning')
        return redirect(url_for('admin_deposits'))
    if action == 'confirm':
        deposit.status = 'confirmed'
        deposit.confirmed_at = datetime.utcnow()
        add_funds(deposit.user_id, deposit.amount, f'Пополнение баланса #{deposit.id}')
        flash(f'Пополнение #{deposit.id} подтверждено', 'success')
    elif action == 'reject':
        deposit.status = 'rejected'
        flash(f'Пополнение #{deposit.id} отклонено', 'warning')
    else:
        flash('Неизвестное действие', 'error')
    db.session.commit()
    return redirect(url_for('admin_deposits'))

@app.route('/admin/withdrawals')
@login_required
@admin_required
def admin_withdrawals():
    withdrawals = Withdrawal.query.order_by(Withdrawal.created_at.desc()).all()
    return render_template('admin_withdrawals.html', withdrawals=withdrawals)

@app.route('/admin/withdrawals/<int:withdrawal_id>/<action>', methods=['POST'])
@login_required
@admin_required
def handle_withdrawal(withdrawal_id, action):
    withdrawal = db.session.get(Withdrawal, withdrawal_id)
    if not withdrawal:
        flash('Заявка не найдена', 'error')
        return redirect(url_for('admin_withdrawals'))
    if withdrawal.status != 'pending':
        flash('Заявка уже обработана', 'warning')
        return redirect(url_for('admin_withdrawals'))
    if action == 'complete':
        withdrawal.status = 'completed'
        withdrawal.completed_at = datetime.utcnow()
        balance = get_balance(withdrawal.user_id)
        if balance.amount >= withdrawal.amount:
            balance.amount -= withdrawal.amount
            db.session.commit()
            flash(f'Вывод #{withdrawal.id} выполнен', 'success')
        else:
            flash('Недостаточно средств на балансе', 'error')
            return redirect(url_for('admin_withdrawals'))
    elif action == 'reject':
        withdrawal.status = 'rejected'
        flash(f'Вывод #{withdrawal.id} отклонён', 'warning')
    else:
        flash('Неизвестное действие', 'error')
    db.session.commit()
    return redirect(url_for('admin_withdrawals'))

with app.app_context():
    migrate_database()
    if os.environ.get('BOOTSTRAP_ADMIN', '').lower() in {'1', 'true', 'yes'}:
        admin_username = os.environ.get('BOOTSTRAP_ADMIN_USERNAME')
        admin_email = os.environ.get('BOOTSTRAP_ADMIN_EMAIL')
        admin_password = os.environ.get('BOOTSTRAP_ADMIN_PASSWORD')
        if not all((admin_username, admin_email, admin_password)):
            raise RuntimeError(
                'Для создания администратора задайте BOOTSTRAP_ADMIN_USERNAME, '
                'BOOTSTRAP_ADMIN_EMAIL и BOOTSTRAP_ADMIN_PASSWORD.'
            )
        if not User.query.filter_by(role='admin').first():
            admin = User(
                username=admin_username,
                email=admin_email,
                password_hash=generate_password_hash(admin_password, method='pbkdf2:sha256'),
                role='admin',
            )
            db.session.add(admin)
            db.session.commit()

if __name__ == '__main__':
    port = int(os.environ.get('PORT', '5000'))
    debug = os.environ.get('FLASK_DEBUG', '').lower() in {'1', 'true', 'yes'}
    app.run(debug=debug, host='0.0.0.0', port=port)