document.addEventListener('DOMContentLoaded', () => {
  window.setTimeout(() => {
    document.querySelectorAll('.alert').forEach((el) => {
      if (window.bootstrap) bootstrap.Alert.getOrCreateInstance(el).close();
    });
  }, 5000);

  document.querySelectorAll('form').forEach((form) => {
    form.addEventListener('submit', (event) => {
      const required = [...form.querySelectorAll('[required]')];
      const invalid = required.some((field) => !String(field.value || '').trim());
      required.forEach((field) => field.classList.toggle('is-invalid', !String(field.value || '').trim()));
      if (invalid) {
        event.preventDefault();
        return;
      }
      const submit = form.querySelector('button[type="submit"]');
      if (submit && form.checkValidity() && !submit.classList.contains('delete-confirm') && !form.dataset.noLock) {
        submit.disabled = true;
        submit.innerHTML = '<span class="spinner-border spinner-border-sm me-2" aria-hidden="true"></span>Сохраняем…';
      }
    });
  });

  document.querySelectorAll('.navbar-collapse a.nav-link').forEach((link) => {
    link.addEventListener('click', () => {
      const menu = link.closest('.navbar-collapse');
      if (menu?.classList.contains('show') && window.bootstrap) {
        bootstrap.Collapse.getOrCreateInstance(menu).hide();
      }
    });
  });

  document.querySelectorAll('input[type="file"][accept*="image"]').forEach((input) => {
    input.addEventListener('change', () => {
      const file = input.files?.[0];
      if (!file || !file.type.startsWith('image/')) return;
      const reader = new FileReader();
      reader.onload = (event) => {
        const container = input.parentElement;
        container.querySelector('.image-preview')?.remove();
        const preview = document.createElement('img');
        preview.src = event.target.result;
        preview.alt = 'Предпросмотр';
        preview.className = 'image-preview img-fluid rounded-3 mt-2';
        preview.style.maxHeight = '180px';
        container.appendChild(preview);
      };
      reader.readAsDataURL(file);
    });
  });

  document.querySelectorAll('.delete-confirm').forEach((btn) => {
    btn.addEventListener('click', (event) => {
      if (!window.confirm('Удалить товар? Это действие нельзя отменить.')) event.preventDefault();
    });
  });

  document.querySelectorAll('.filter-select').forEach((filter) => {
    filter.addEventListener('change', () => filter.closest('form')?.submit());
  });

  const activeTab = localStorage.getItem('activeTab');
  if (activeTab && window.bootstrap) {
    const trigger = document.querySelector(`[data-bs-target="${CSS.escape(activeTab)}"]`);
    if (trigger) bootstrap.Tab.getOrCreateInstance(trigger).show();
  }
  document.querySelectorAll('[data-bs-toggle="tab"]').forEach((trigger) => {
    trigger.addEventListener('shown.bs.tab', (event) => {
      localStorage.setItem('activeTab', event.target.getAttribute('data-bs-target'));
    });
  });

  document.querySelectorAll('.table-search').forEach((input) => {
    input.addEventListener('input', (event) => {
      const query = event.target.value.toLowerCase();
      const table = (input.closest('.card-body') || input.closest('.card') || document).querySelector('table');
      if (!table) return;
      table.querySelectorAll('tbody tr').forEach((row) => {
        row.style.display = row.textContent.toLowerCase().includes(query) ? '' : 'none';
      });
    });
  });
});
