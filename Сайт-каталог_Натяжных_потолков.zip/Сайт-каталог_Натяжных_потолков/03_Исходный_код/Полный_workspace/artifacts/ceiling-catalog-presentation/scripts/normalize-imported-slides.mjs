import fs from "node:fs";
import path from "node:path";

const slidesDir = path.resolve("artifacts/ceiling-catalog-presentation/src/pages/slides");

const shared = {
  "Дипломный проект • Матвей Намазов • Разработчик веб-приложений на Python":
    "Дипломный проект • Матвей Намазов • Сайт-каталог натяжных потолков",
};

const copy = {
  Slide1: {
    "Каталог товаров, личные кабинеты, модерация и оформление заказов":
      "Каталог товаров, регистрация, модерация и заявки без оплаты",
  },
  Slide2: {
    "Как покупатель проходит путь": "Кому нужен сайт-каталог",
    "Покупатель": "Покупатель",
    "Находит товар, задаёт вопрос или оформляет заказ.":
      "Смотрит одобренные товары и отправляет заявку без оплаты.",
    "Продавец": "Продавец",
    "Добавляет и редактирует свои карточки; общается с покупателями.":
      "Добавляет и редактирует карточки; отправляет их на проверку.",
    "Администратор": "Администратор",
    "Проверяет карточки и обращения; управляет аккаунтами.":
      "Проверяет товары, заявки, пользователей и обращения поддержки.",
    "ПРОДАВЕЦ ДОБАВЛЯЕТ → АДМИН ПРОВЕРЯЕТ → ТОВАР В КАТАЛОГЕ → ВОПРОС ИЛИ ЗАКАЗ":
      "ПРОДАВЕЦ ДОБАВЛЯЕТ → АДМИН ПРОВЕРЯЕТ → ТОВАР В КАТАЛОГЕ → ЗАЯВКА ПОКУПАТЕЛЯ",
  },
  Slide3: {
    "Что происходит после нажатия кнопки": "Из чего состоит сайт",
    "Страницы": "Интерфейс",
    "Flask подставляет данные в HTML-шаблоны; внешний вид задают CSS и JavaScript.":
      "React и Vite формируют страницы каталога, регистрации и кабинетов.",
    "Обработка": "Сервер API",
    "Flask принимает запрос, запускает маршрут и возвращает страницу.":
      "Express API проверяет запросы и выполняет операции с данными.",
    "База данных": "База данных",
    "По умолчанию используется SQLite; DATABASE_URL позволяет подключить PostgreSQL.":
      "PostgreSQL хранит аккаунты, товары, заявки и обращения поддержки.",
    "Три строки из app.py: создаём приложение, подключаем базу и вход.":
      "Вход и регистрация работают через Clerk. Shopify и онлайн-оплата не используются.",
  },
  Slide4: {
    "User — аккаунт и роль. Его id связывает человека с его товарами и заказами.":
      "Account — пользователь и его роль. Администратора нельзя выбрать при регистрации.",
    "Product — карточка товара. seller_id связывает её с продавцом, is_approved хранит статус проверки.":
      "SellerProduct — карточка продавца со статусом проверки и публикации.",
    "Request — вопрос по товару. Order — оформленная покупка. Это разные записи.":
      "Request — заявка покупателя без оплаты. SupportTicket хранит обращения и переписку.",
    "Фрагмент модели: продавец связан с карточкой, публикация отмечается отдельным флагом.":
      "Данные сохраняются в PostgreSQL; платёжных записей в проекте нет.",
  },
  Slide5: {
    "Кто может выполнить действие": "Доступ зависит от роли",
    "Сервер проверяет вход, блокировку и роль до показа закрытой страницы.":
      "Clerk подтверждает вход; API проверяет роль перед закрытыми действиями.",
    "Пароль": "Роль аккаунта",
    "В базе хранится хэш пароля, а не сам пароль. При регистрации доступны покупатель и продавец.":
      "При регистрации доступны покупатель и продавец. Первого администратора назначает сервер.",
    "Сервер проверяет цену и тип файла с изображением до сохранения.":
      "API проверяет поля карточки перед сохранением; товар ожидает проверки.",
    "Своя карточка": "Права продавца",
    "Продавец может редактировать только свой товар; чат открыт только его участникам.":
      "Продавец управляет только своими товарами; администратор проверяет публикацию.",
  },
  Slide6: {
    "Продавец указывает цену и характеристики.":
      "Продавец добавляет название, цену и характеристики товара.",
    "В коде это два правила: новая карточка скрыта, каталог выбирает только одобренные.":
      "Покупатель видит товары только после проверки администратором.",
  },
  Slide7: {
    "06 • ОБЩЕНИЕ": "06 • ЗАЯВКИ И ПОДДЕРЖКА",
    "Вопрос, чат и предложение — разные вещи": "Заявка не равна заказу",
    "Заявка Request": "Заявка покупателя",
    "Request — вопрос покупателя о товаре. Пустое сообщение не сохраняется.":
      "Покупатель указывает товар и контакт, добавляет комментарий и подтверждает согласие.",
    "Чат Message": "Поддержка",
    "Message — переписка покупателя и продавца по выбранному товару.":
      "Пользователь пишет обращение; администратор отвечает в защищённой переписке.",
    "Предложение цены": "Без онлайн-оплаты",
    "Продавец может предложить цену. Администратор проверяет предложение, затем покупатель решает, оплачивать ли его.":
      "Заявка передаётся продавцу для связи. Сайт не списывает деньги и не подтверждает продажу.",
    "В модели Request отдельно хранятся текст обращения и его статус.":
      "Администратор видит заявки и обращения в панели управления.",
  },
  Slide8: {
    "07 • ЗАКАЗ": "07 • УСЛОВИЯ ДЛЯ ПРОДАВЦА",
    "Что происходит при оформлении заказа": "Комиссия указана в черновике договора",
    "Корзина": "Ставка",
    "В корзину попадают опубликованные товары и их количество.":
      "В черновике договора указана ставка 15%.",
    "Оформление": "Условие",
    "Перед оформлением проверяются адрес, сумма и продавец. Товары разных продавцов оформляются отдельно.":
      "Формулировка «от 10 товаров» требует уточнения сторонами.",
    "Завершение": "База расчёта",
    "Сумма резервируется. После доставки покупатель подтверждает получение, а администратор завершает заказ.":
      "Нужно согласовать базу, момент начисления, возвраты и сроки выплат.",
    "В коде проверяется не общий баланс, а сумма за вычетом уже зарезервированных средств.":
      "Сайт не рассчитывает и не переводит комиссию автоматически.",
  },
  Slide9: {
    "08 • ИНТЕРФЕЙС И ПОДДЕРЖКА": "08 • ИНТЕРФЕЙС И АДМИНИСТРИРОВАНИЕ",
    "Основные страницы приложения": "Для каждой роли — свой кабинет",
    "Flask-шаблоны формируют каталог, карточку товара и личные кабинеты.":
      "Покупатель просматривает каталог и отправляет заявку без оплаты.",
    "Обратная связь": "Продавец",
    "Покупатель может оставить отзыв или написать в поддержку.":
      "Создаёт и редактирует карточки, следит за результатом проверки.",
    "Администратор проверяет товары, управляет пользователями и обрабатывает заказы и обращения.":
      "Администратор модерирует товары, управляет пользователями и отвечает на обращения.",
    "Вставка показывает HTML карточки; сам сайт лучше открыть в браузере во время защиты.":
      "Административные разделы доступны только после входа и проверки роли.",
  },
  Slide10: {
    "09 • СООТВЕТСТВИЕ МЕТОДИЧКЕ": "09 • ГОТОВНОСТЬ ПРОЕКТА",
    "Что подтверждено и что ещё показать": "Реализовано и подготовлено",
    "Есть в исходниках": "Реализовано",
    "Python и Flask; модели базы данных; роли и проверки; каталог и модерация; корзина и заказы.":
      "React, Express API и PostgreSQL; регистрация; роли; каталог; модерация; заявки; поддержка.",
    "Нужно добавить перед защитой": "Нужно заполнить перед публикацией",
    "Ссылки на сайт-портфолио, репозиторий и публикацию; примеры Figma и айдентики; доказательство тестирования API, если оно есть.":
      "Реальные товары; контакты владельца и документы о данных; production-ключи Clerk; ссылки на сайт и репозиторий.",
    "В Flask-приложении страницы возвращаются как HTML; полноценные JSON-маршруты каталога и публичный адрес в архиве не подтверждены.":
      "Каталог ждёт реальные карточки. Условия договора с продавцом требуют согласования.",
  },
  Slide11: {
    "Ссылки, которые нужно добавить перед защитой":
      "Проект готов к заполнению реальными данными",
    "В приложении можно показать путь товара: карточка продавца → проверка → каталог → вопрос или заказ.":
      "Путь товара: карточка продавца → проверка администратором → публикация в каталоге.",
    "Облачная папка сайта": "Каталог и заявки без онлайн-оплаты",
    "Опубликованное приложение": "Регистрация, кабинеты и поддержка",
    "Спасибо. Готов показать работу каталога и ответить на вопросы.":
      "Спасибо. Готов показать работу сайта и ответить на вопросы.",
  },
};

const outputs = [];

const unicodeEscape = (value) =>
  JSON.stringify(value)
    .slice(1, -1)
    .replace(/[\u007f-\uffff]/g, (character) =>
      `\\u${character.charCodeAt(0).toString(16).padStart(4, "0")}`,
    );

const asViewportUnit = (property, value) => {
  const number = Number.parseFloat(value);
  const horizontal = new Set([
    "left", "right", "width", "minWidth", "maxWidth",
    "paddingLeft", "paddingRight", "marginLeft", "marginRight",
  ]);
  const base = horizontal.has(property) ? 1280 : 720;
  const unit = horizontal.has(property) ? "vw" : "vh";
  return `${Number(((number / base) * 100).toFixed(4))}${unit}`;
};

const convertPadding = (value) => {
  const parts = value.trim().split(/\s+/);
  if (parts.length < 1 || parts.length > 4) return value;
  const dimensions = parts.map((part, index) => {
    const match = part.match(/^(-?[\d.]+)px$/);
    if (!match) return part;
    const isHorizontal = parts.length === 1
      ? true
      : parts.length === 2
        ? index === 1
        : parts.length === 3
          ? index === 1
          : index === 1 || index === 3;
    const property = isHorizontal ? "width" : "height";
    return asViewportUnit(property, match[1]);
  });
  return dimensions.join(" ");
};

for (let slideNumber = 1; slideNumber <= 11; slideNumber += 1) {
  const name = `Slide${slideNumber}`;
  const filePath = path.join(slidesDir, `${name}.tsx`);
  let source = fs.readFileSync(filePath, "utf8");
  const replacements = {
    ...(slideNumber === 1 ? {} : shared),
    ...copy[name],
  };
  const replaced = new Set();

  source = source.replace(/\{"((?:\\.|[^"\\])*)"\}/g, (match, encoded) => {
    let visibleText;
    try {
      visibleText = JSON.parse(`"${encoded}"`).replace(/\s+/g, " ").trim();
    } catch {
      return match;
    }
    if (!(visibleText in replacements)) return match;
    replaced.add(visibleText);
    return `{"${unicodeEscape(replacements[visibleText])}"}`;
  });

  const missing = Object.keys(replacements).filter((value) => !replaced.has(value));
  if (missing.length) {
    throw new Error(`${name}: source text not found: ${missing.join(" | ")}`);
  }

  source = source.replace(
    'import React, { useState, useEffect, useRef } from "react";',
    'import React from "react";',
  );

  const wrapperPattern =
    /  const outerRef = useRef<HTMLDivElement>\(null\);[\s\S]*?  return <div id="slide-(\d+)" ref=\{outerRef\} className="w-screen h-screen overflow-hidden relative" style=\{\{\s*backgroundColor: "#000"\s*\}\}><div id="slide-inner-\d+" style=\{\{[\s\S]*?top: layout\.y \+ "px"\s*\}\}>/;
  const wrapperMatch = source.match(wrapperPattern);
  if (!wrapperMatch) {
    throw new Error(`${name}: imported scale wrapper was not found`);
  }
  source = source.replace(
    wrapperPattern,
    `  return <div id="slide-${wrapperMatch[1]}" className="w-screen h-screen overflow-hidden relative" style={{backgroundColor:"#000"}}>`,
  );

  source = source.replace(
    /\b(left|right|width|minWidth|maxWidth|paddingLeft|paddingRight|marginLeft|marginRight|top|bottom|height|minHeight|maxHeight|paddingTop|paddingBottom|marginTop|marginBottom):\s*"(-?[\d.]+)px"/g,
    (_match, property, value) => `${property}: "${asViewportUnit(property, value)}"`,
  );
  source = source.replace(
    /\bpadding:\s*"([^"]+)"/g,
    (_match, value) => `padding: "${convertPadding(value)}"`,
  );
  source = source.replace(
    /fontSize:\s*"calc\(([\d.]+)pt \* var\(--pptx-font-scale,\s*1\)\)"/g,
    (_match, points) => {
      const vw = Math.max(1.5, Number(points) * 0.1041667);
      return `fontSize: "${Number(vw.toFixed(4))}vw"`;
    },
  );

  const closingPattern = /<\/div><\/div>;\s*};\s*export default (Slide\d+);/;
  if (!closingPattern.test(source)) {
    throw new Error(`${name}: imported wrapper closing tags were not found`);
  }
  source = source.replace(closingPattern, "</div>;\n};\nexport default $1;");

  if (source.includes("pptx-font-scale") || source.includes("layout.s")) {
    throw new Error(`${name}: stale scale wrapper remains`);
  }
  outputs.push({ filePath, name, source, replacementCount: replaced.size });
}

for (const output of outputs) {
  fs.writeFileSync(output.filePath, output.source);
  console.log(
    `${output.name}: updated ${output.replacementCount} text labels and normalized frame`,
  );
}
