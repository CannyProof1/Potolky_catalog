import fs from "node:fs";
import path from "node:path";

const slidesDir = path.resolve("artifacts/ceiling-catalog-presentation/src/pages/slides");
const altText = {
  Slide3: "Главная страница каталога",
  Slide4: "Схема таблиц базы данных",
  Slide7: "Сценарий заявки без онлайн-оплаты",
};

for (let slideNumber = 1; slideNumber <= 11; slideNumber += 1) {
  const name = `Slide${slideNumber}`;
  const filePath = path.join(slidesDir, `${name}.tsx`);
  let source = fs.readFileSync(filePath, "utf8");

  source = source.replace(
    /<img(\s+key=\{\d+\}\s+src=\{img_\d+\})\s+alt=/g,
    '<img$1 crossOrigin="anonymous" alt=',
  );

  if (altText[name]) {
    source = source.replace(
      /(<img\s+key=\{19\}\s+src=\{img_1\}\s+crossOrigin="anonymous"\s+alt=")[^"]*(")/,
      `$1${altText[name]}$2`,
    );
  }
  if (name === "Slide8") {
    source = source.replace(
      /(<img\s+key=\{19\}\s+src=\{img_1\}\s+crossOrigin="anonymous"\s+alt=")[^"]*(")/,
      '$1Условия размещения для продавцов$2',
    );
    source = source.replace(
      /(<img\s+key=\{20\}\s+src=\{img_2\}\s+crossOrigin="anonymous"\s+alt=")[^"]*(")/,
      '$1Главная страница каталога$2',
    );
  }

  if (name === "Slide4") {
    source = source
      .replace(/\{"User"\}/g, '{"Аккаунты"}')
      .replace(/\{"Product"\}/g, '{"Товары"}')
      .replace(/\{"Request \/ Order"\}/g, '{"Заявки и поддержка"}');
  }

  fs.writeFileSync(filePath, source);
}

console.log("Added image accessibility labels and localized table headings.");
