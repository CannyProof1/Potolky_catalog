import React from "react";
const Slide10: React.FC = () => {
  return <div id="slide-10" className="w-screen h-screen overflow-hidden relative" style={{backgroundColor:"#000"}}><div key={0} style={{
        position: "absolute",
        left: "0vw",
        top: "0vh",
        width: "99.9922vw",
        height: "99.9889vh",
        boxSizing: "border-box",
        backgroundColor: "#f7f9fb",
        boxShadow: "0px 2.42px 4.2px rgba(0, 0, 0, 0.35)"
      }} /><div key={1} style={{
        position: "absolute",
        left: "4.6508vw",
        top: "4.5361vh",
        width: "90.3687vw",
        height: "3.0181vh",
        boxSizing: "border-box",
        backgroundColor: "transparent",
        padding: "0.3986vh 0.2242vw 0.3986vh 0.2242vw",
        wordWrap: "break-word"
      }}><p style={{
          lineHeight: "1.2",
          fontSize: "1.5vw",
          marginTop: "0",
          marginBottom: "0"
        }}><span style={{
            fontSize: "1.5vw",
            fontFamily: "'Aptos', sans-serif",
            fontWeight: "700",
            color: "#1f9f8b",
            letterSpacing: "-0.01pt"
          }}>{"09 \u2022 \u0413\u041e\u0422\u041e\u0412\u041d\u041e\u0421\u0422\u042c \u041f\u0420\u041e\u0415\u041a\u0422\u0410"}</span></p></div><div key={2} style={{
        position: "absolute",
        left: "4.6508vw",
        top: "9.2028vh",
        width: "90.3687vw",
        height: "7.0181vh",
        boxSizing: "border-box",
        backgroundColor: "transparent",
        padding: "0.3986vh 0.2242vw 0.3986vh 0.2242vw",
        wordWrap: "break-word"
      }}><p style={{
          lineHeight: "1.2",
          fontSize: "2.9167vw",
          marginTop: "0",
          marginBottom: "0"
        }}><span style={{
            fontSize: "2.9167vw",
            fontFamily: "'Aptos', sans-serif",
            fontWeight: "700",
            color: "#14263d",
            letterSpacing: "-0.01pt"
          }}>{"\u0420\u0435\u0430\u043b\u0438\u0437\u043e\u0432\u0430\u043d\u043e \u0438 \u043f\u043e\u0434\u0433\u043e\u0442\u043e\u0432\u043b\u0435\u043d\u043e"}</span></p></div><div key={3} style={{
        position: "absolute",
        left: "4.6508vw",
        top: "18.3986vh",
        width: "90.3687vw",
        height: "0.325vh",
        boxSizing: "border-box",
        backgroundColor: "#dde4eb",
        boxShadow: "0px 2.42px 4.2px rgba(0, 0, 0, 0.35)"
      }} /><div key={4} style={{
        position: "absolute",
        left: "4.6508vw",
        top: "94.9347vh",
        width: "73.4938vw",
        height: "2.7931vh",
        boxSizing: "border-box",
        backgroundColor: "transparent",
        padding: "0.3986vh 0.2242vw 0.3986vh 0.2242vw",
        wordWrap: "break-word"
      }}><p style={{
          lineHeight: "1.2",
          fontSize: "1.5vw",
          marginTop: "0",
          marginBottom: "0"
        }}><span style={{
            fontSize: "1.5vw",
            fontFamily: "'Aptos', sans-serif",
            color: "#617182",
            letterSpacing: "-0.01pt"
          }}>{"\u0414\u0438\u043f\u043b\u043e\u043c\u043d\u044b\u0439 \u043f\u0440\u043e\u0435\u043a\u0442 \u2022 \u041c\u0430\u0442\u0432\u0435\u0439 \u041d\u0430\u043c\u0430\u0437\u043e\u0432 \u2022 \u0421\u0430\u0439\u0442-\u043a\u0430\u0442\u0430\u043b\u043e\u0433 \u043d\u0430\u0442\u044f\u0436\u043d\u044b\u0445 \u043f\u043e\u0442\u043e\u043b\u043a\u043e\u0432"}</span></p></div><div key={5} style={{
        position: "absolute",
        left: "87.9008vw",
        top: "94.6667vh",
        width: "7.1188vw",
        height: "2.7931vh",
        boxSizing: "border-box",
        backgroundColor: "transparent",
        padding: "0.3986vh 0.2242vw 0.3986vh 0.2242vw",
        wordWrap: "break-word"
      }}><p style={{
          textAlign: "right",
          lineHeight: "1.2",
          fontSize: "1.5vw",
          marginTop: "0",
          marginBottom: "0"
        }}><span style={{
            fontSize: "1.5vw",
            fontFamily: "'Aptos', sans-serif",
            color: "#617182",
            letterSpacing: "-0.01pt"
          }}>{"10 / 11"}</span></p></div><div key={6} style={{
        position: "absolute",
        left: "4.6508vw",
        top: "22.3986vh",
        width: "44.0938vw",
        height: "50.3889vh",
        boxSizing: "border-box",
        backgroundColor: "#ffffff",
        border: "1.06px solid #dde4eb",
        borderRadius: "60.47px",
        boxShadow: "0px 2.42px 4.2px rgba(0, 0, 0, 0.35)"
      }} /><div key={7} style={{
        position: "absolute",
        left: "4.7242vw",
        top: "24.7972vh",
        width: "0.4078vw",
        height: "37.1444vh",
        boxSizing: "border-box",
        backgroundColor: "#1f9f8b",
        boxShadow: "0px 2.42px 4.2px rgba(0, 0, 0, 0.35)"
      }} /><div key={8} style={{
        position: "absolute",
        left: "6.4484vw",
        top: "24.7972vh",
        width: "40.943vw",
        height: "4.5778vh",
        boxSizing: "border-box",
        backgroundColor: "transparent",
        padding: "0.3986vh 0.2242vw 0.3986vh 0.2242vw",
        wordWrap: "break-word"
      }}><p style={{
          lineHeight: "1.2",
          fontSize: "1.7708vw",
          marginTop: "0",
          marginBottom: "0"
        }}><span style={{
            fontSize: "1.7708vw",
            fontFamily: "'Aptos', sans-serif",
            fontWeight: "700",
            color: "#14263d",
            letterSpacing: "-0.01pt"
          }}>{"\u0420\u0435\u0430\u043b\u0438\u0437\u043e\u0432\u0430\u043d\u043e"}</span></p></div><div key={9} style={{
        position: "absolute",
        left: "6.4484vw",
        top: "30.6667vh",
        width: "40.7953vw",
        height: "7.25vh",
        boxSizing: "border-box",
        backgroundColor: "transparent",
        padding: "0.3986vh 0.2242vw 0.3986vh 0.2242vw",
        wordWrap: "break-word"
      }}><p style={{
          lineHeight: "1.2",
          fontSize: "1.5104vw",
          marginTop: "0",
          marginBottom: "0"
        }}><span style={{
            fontSize: "1.5104vw",
            fontFamily: "'Aptos', sans-serif",
            color: "#243447",
            letterSpacing: "-0.01pt"
          }}>{"React, Express API \u0438 PostgreSQL; \u0440\u0435\u0433\u0438\u0441\u0442\u0440\u0430\u0446\u0438\u044f; \u0440\u043e\u043b\u0438; \u043a\u0430\u0442\u0430\u043b\u043e\u0433; \u043c\u043e\u0434\u0435\u0440\u0430\u0446\u0438\u044f; \u0437\u0430\u044f\u0432\u043a\u0438; \u043f\u043e\u0434\u0434\u0435\u0440\u0436\u043a\u0430."}</span></p></div><div key={10} style={{
        position: "absolute",
        left: "51.1508vw",
        top: "22.3986vh",
        width: "44.1703vw",
        height: "50.3889vh",
        boxSizing: "border-box",
        backgroundColor: "#fff5e2",
        border: "1.06px solid #dde4eb",
        borderRadius: "60.47px",
        boxShadow: "0px 2.42px 4.2px rgba(0, 0, 0, 0.35)"
      }} /><div key={11} style={{
        position: "absolute",
        left: "51.2242vw",
        top: "24.7972vh",
        width: "0.4078vw",
        height: "37.1444vh",
        boxSizing: "border-box",
        backgroundColor: "#d99137",
        boxShadow: "0px 2.42px 4.2px rgba(0, 0, 0, 0.35)"
      }} /><div key={12} style={{
        position: "absolute",
        left: "52.9484vw",
        top: "24.7972vh",
        width: "41.0195vw",
        height: "4.5778vh",
        boxSizing: "border-box",
        backgroundColor: "transparent",
        padding: "0.3986vh 0.2242vw 0.3986vh 0.2242vw",
        wordWrap: "break-word"
      }}><p style={{
          lineHeight: "1.2",
          fontSize: "1.7708vw",
          marginTop: "0",
          marginBottom: "0"
        }}><span style={{
            fontSize: "1.7708vw",
            fontFamily: "'Aptos', sans-serif",
            fontWeight: "700",
            color: "#14263d",
            letterSpacing: "-0.01pt"
          }}>{"\u041d\u0443\u0436\u043d\u043e \u0437\u0430\u043f\u043e\u043b\u043d\u0438\u0442\u044c \u043f\u0435\u0440\u0435\u0434 \u043f\u0443\u0431\u043b\u0438\u043a\u0430\u0446\u0438\u0435\u0439"}</span></p></div><div key={13} style={{
        position: "absolute",
        left: "52.9484vw",
        top: "30.6667vh",
        width: "40.8687vw",
        height: "10.1264vh",
        boxSizing: "border-box",
        backgroundColor: "transparent",
        padding: "0.3986vh 0.2242vw 0.3986vh 0.2242vw",
        wordWrap: "break-word"
      }}><p style={{
          lineHeight: "1.2",
          fontSize: "1.5vw",
          marginTop: "0",
          marginBottom: "0"
        }}><span style={{
            fontSize: "1.5vw",
            fontFamily: "'Aptos', sans-serif",
            color: "#243447",
            letterSpacing: "-0.01pt"
          }}>{"\u0420\u0435\u0430\u043b\u044c\u043d\u044b\u0435 \u0442\u043e\u0432\u0430\u0440\u044b; \u043a\u043e\u043d\u0442\u0430\u043a\u0442\u044b \u0432\u043b\u0430\u0434\u0435\u043b\u044c\u0446\u0430 \u0438 \u0434\u043e\u043a\u0443\u043c\u0435\u043d\u0442\u044b \u043e \u0434\u0430\u043d\u043d\u044b\u0445; production-\u043a\u043b\u044e\u0447\u0438 Clerk; \u0441\u0441\u044b\u043b\u043a\u0438 \u043d\u0430 \u0441\u0430\u0439\u0442 \u0438 \u0440\u0435\u043f\u043e\u0437\u0438\u0442\u043e\u0440\u0438\u0439."}</span></p></div><div key={14} style={{
        position: "absolute",
        left: "6.1508vw",
        top: "77.0653vh",
        width: "87.3687vw",
        height: "6.3458vh",
        boxSizing: "border-box",
        backgroundColor: "transparent",
        padding: "0.3986vh 0.2242vw 0.3986vh 0.2242vw",
        wordWrap: "break-word"
      }}><p style={{
          textAlign: "center",
          lineHeight: "1.2",
          fontSize: "1.5vw",
          marginTop: "0",
          marginBottom: "0"
        }}><span style={{
            fontSize: "1.5vw",
            fontFamily: "'Aptos', sans-serif",
            color: "#4d6073",
            letterSpacing: "-0.01pt"
          }}>{"\u041a\u0430\u0442\u0430\u043b\u043e\u0433 \u0436\u0434\u0451\u0442 \u0440\u0435\u0430\u043b\u044c\u043d\u044b\u0435 \u043a\u0430\u0440\u0442\u043e\u0447\u043a\u0438. \u0423\u0441\u043b\u043e\u0432\u0438\u044f \u0434\u043e\u0433\u043e\u0432\u043e\u0440\u0430 \u0441 \u043f\u0440\u043e\u0434\u0430\u0432\u0446\u043e\u043c \u0442\u0440\u0435\u0431\u0443\u044e\u0442 \u0441\u043e\u0433\u043b\u0430\u0441\u043e\u0432\u0430\u043d\u0438\u044f."}</span></p></div></div>;
};
export default Slide10;
