import React from "react";
import img_1 from "./assets/images/image_4.png";
import img_2 from "./assets/images/image_5.png";
const Slide8: React.FC = () => {
  return <div id="slide-8" className="w-screen h-screen overflow-hidden relative" style={{backgroundColor:"#000"}}><div key={0} style={{
        position: "absolute",
        left: "0vw",
        top: "0vh",
        width: "99.9922vw",
        height: "99.9889vh",
        boxSizing: "border-box",
        backgroundColor: "#f7f9fb",
        boxShadow: "0px 2.42px 4.2px rgba(0, 0, 0, 0.35)"
      }} /><div key={1} style={{
        position: "absolute",
        left: "4.6508vw",
        top: "4.5361vh",
        width: "90.3687vw",
        height: "3.0181vh",
        boxSizing: "border-box",
        backgroundColor: "transparent",
        padding: "0.3986vh 0.2242vw 0.3986vh 0.2242vw",
        wordWrap: "break-word"
      }}><p style={{
          lineHeight: "1.2",
          fontSize: "1.5vw",
          marginTop: "0",
          marginBottom: "0"
        }}><span style={{
            fontSize: "1.5vw",
            fontFamily: "'Aptos', sans-serif",
            fontWeight: "700",
            color: "#1f9f8b",
            letterSpacing: "-0.01pt"
          }}>{"07 \u2022 \u0423\u0421\u041b\u041e\u0412\u0418\u042f \u0414\u041b\u042f \u041f\u0420\u041e\u0414\u0410\u0412\u0426\u0410"}</span></p></div><div key={2} style={{
        position: "absolute",
        left: "4.6508vw",
        top: "9.2028vh",
        width: "90.3687vw",
        height: "7.0181vh",
        boxSizing: "border-box",
        backgroundColor: "transparent",
        padding: "0.3986vh 0.2242vw 0.3986vh 0.2242vw",
        wordWrap: "break-word"
      }}><p style={{
          lineHeight: "1.2",
          fontSize: "2.9167vw",
          marginTop: "0",
          marginBottom: "0"
        }}><span style={{
            fontSize: "2.9167vw",
            fontFamily: "'Aptos', sans-serif",
            fontWeight: "700",
            color: "#14263d",
            letterSpacing: "-0.01pt"
          }}>{"\u041a\u043e\u043c\u0438\u0441\u0441\u0438\u044f \u0443\u043a\u0430\u0437\u0430\u043d\u0430 \u0432 \u0447\u0435\u0440\u043d\u043e\u0432\u0438\u043a\u0435 \u0434\u043e\u0433\u043e\u0432\u043e\u0440\u0430"}</span></p></div><div key={3} style={{
        position: "absolute",
        left: "4.6508vw",
        top: "18.3986vh",
        width: "90.3687vw",
        height: "0.325vh",
        boxSizing: "border-box",
        backgroundColor: "#dde4eb",
        boxShadow: "0px 2.42px 4.2px rgba(0, 0, 0, 0.35)"
      }} /><div key={4} style={{
        position: "absolute",
        left: "4.6508vw",
        top: "94.9347vh",
        width: "73.4938vw",
        height: "2.7931vh",
        boxSizing: "border-box",
        backgroundColor: "transparent",
        padding: "0.3986vh 0.2242vw 0.3986vh 0.2242vw",
        wordWrap: "break-word"
      }}><p style={{
          lineHeight: "1.2",
          fontSize: "1.5vw",
          marginTop: "0",
          marginBottom: "0"
        }}><span style={{
            fontSize: "1.5vw",
            fontFamily: "'Aptos', sans-serif",
            color: "#617182",
            letterSpacing: "-0.01pt"
          }}>{"\u0414\u0438\u043f\u043b\u043e\u043c\u043d\u044b\u0439 \u043f\u0440\u043e\u0435\u043a\u0442 \u2022 \u041c\u0430\u0442\u0432\u0435\u0439 \u041d\u0430\u043c\u0430\u0437\u043e\u0432 \u2022 \u0421\u0430\u0439\u0442-\u043a\u0430\u0442\u0430\u043b\u043e\u0433 \u043d\u0430\u0442\u044f\u0436\u043d\u044b\u0445 \u043f\u043e\u0442\u043e\u043b\u043a\u043e\u0432"}</span></p></div><div key={5} style={{
        position: "absolute",
        left: "87.9008vw",
        top: "94.6667vh",
        width: "7.1188vw",
        height: "2.7931vh",
        boxSizing: "border-box",
        backgroundColor: "transparent",
        padding: "0.3986vh 0.2242vw 0.3986vh 0.2242vw",
        wordWrap: "break-word"
      }}><p style={{
          textAlign: "right",
          lineHeight: "1.2",
          fontSize: "1.5vw",
          marginTop: "0",
          marginBottom: "0"
        }}><span style={{
            fontSize: "1.5vw",
            fontFamily: "'Aptos', sans-serif",
            color: "#617182",
            letterSpacing: "-0.01pt"
          }}>{"08 / 11"}</span></p></div><div key={6} style={{
        position: "absolute",
        left: "4.6508vw",
        top: "22.9347vh",
        width: "28.7188vw",
        height: "36.6556vh",
        boxSizing: "border-box",
        backgroundColor: "#ffffff",
        border: "1.06px solid #dde4eb",
        borderRadius: "43.99px",
        boxShadow: "0px 2.42px 4.2px rgba(0, 0, 0, 0.35)"
      }} /><div key={7} style={{
        position: "absolute",
        left: "4.7242vw",
        top: "25.3333vh",
        width: "0.4078vw",
        height: "31.8583vh",
        boxSizing: "border-box",
        backgroundColor: "#1f9f8b",
        boxShadow: "0px 2.42px 4.2px rgba(0, 0, 0, 0.35)"
      }} /><div key={8} style={{
        position: "absolute",
        left: "6.4484vw",
        top: "25.3333vh",
        width: "25.568vw",
        height: "4.5778vh",
        boxSizing: "border-box",
        backgroundColor: "transparent",
        padding: "0.3986vh 0.2242vw 0.3986vh 0.2242vw",
        wordWrap: "break-word"
      }}><p style={{
          lineHeight: "1.2",
          fontSize: "1.7708vw",
          marginTop: "0",
          marginBottom: "0"
        }}><span style={{
            fontSize: "1.7708vw",
            fontFamily: "'Aptos', sans-serif",
            fontWeight: "700",
            color: "#14263d",
            letterSpacing: "-0.01pt"
          }}>{"\u0421\u0442\u0430\u0432\u043a\u0430"}</span></p></div><div key={9} style={{
        position: "absolute",
        left: "6.4484vw",
        top: "31.2028vh",
        width: "25.4203vw",
        height: "10.4722vh",
        boxSizing: "border-box",
        backgroundColor: "transparent",
        padding: "0.3986vh 0.2242vw 0.3986vh 0.2242vw",
        wordWrap: "break-word"
      }}><p style={{
          lineHeight: "1.2",
          fontSize: "1.5104vw",
          marginTop: "0",
          marginBottom: "0"
        }}><span style={{
            fontSize: "1.5104vw",
            fontFamily: "'Aptos', sans-serif",
            color: "#243447",
            letterSpacing: "-0.01pt"
          }}>{"\u0412 \u0447\u0435\u0440\u043d\u043e\u0432\u0438\u043a\u0435 \u0434\u043e\u0433\u043e\u0432\u043e\u0440\u0430 \u0443\u043a\u0430\u0437\u0430\u043d\u0430 \u0441\u0442\u0430\u0432\u043a\u0430 15%."}</span></p></div><div key={10} style={{
        position: "absolute",
        left: "35.5516vw",
        top: "22.9347vh",
        width: "28.7188vw",
        height: "36.6556vh",
        boxSizing: "border-box",
        backgroundColor: "#ffffff",
        border: "1.06px solid #dde4eb",
        borderRadius: "43.99px",
        boxShadow: "0px 2.42px 4.2px rgba(0, 0, 0, 0.35)"
      }} /><div key={11} style={{
        position: "absolute",
        left: "35.625vw",
        top: "25.3333vh",
        width: "0.4078vw",
        height: "31.8583vh",
        boxSizing: "border-box",
        backgroundColor: "#4a84be",
        boxShadow: "0px 2.42px 4.2px rgba(0, 0, 0, 0.35)"
      }} /><div key={12} style={{
        position: "absolute",
        left: "37.3492vw",
        top: "25.3333vh",
        width: "25.568vw",
        height: "4.5778vh",
        boxSizing: "border-box",
        backgroundColor: "transparent",
        padding: "0.3986vh 0.2242vw 0.3986vh 0.2242vw",
        wordWrap: "break-word"
      }}><p style={{
          lineHeight: "1.2",
          fontSize: "1.7708vw",
          marginTop: "0",
          marginBottom: "0"
        }}><span style={{
            fontSize: "1.7708vw",
            fontFamily: "'Aptos', sans-serif",
            fontWeight: "700",
            color: "#14263d",
            letterSpacing: "-0.01pt"
          }}>{"\u0423\u0441\u043b\u043e\u0432\u0438\u0435"}</span></p></div><div key={13} style={{
        position: "absolute",
        left: "37.3492vw",
        top: "31.2028vh",
        width: "25.4203vw",
        height: "16.5667vh",
        boxSizing: "border-box",
        backgroundColor: "transparent",
        padding: "0.3986vh 0.2242vw 0.3986vh 0.2242vw",
        wordWrap: "break-word"
      }}><p style={{
          lineHeight: "1.2",
          fontSize: "1.5vw",
          marginTop: "0",
          marginBottom: "0"
        }}><span style={{
            fontSize: "1.5vw",
            fontFamily: "'Aptos', sans-serif",
            color: "#243447",
            letterSpacing: "-0.01pt"
          }}>{"\u0424\u043e\u0440\u043c\u0443\u043b\u0438\u0440\u043e\u0432\u043a\u0430 \u00ab\u043e\u0442 10 \u0442\u043e\u0432\u0430\u0440\u043e\u0432\u00bb \u0442\u0440\u0435\u0431\u0443\u0435\u0442 \u0443\u0442\u043e\u0447\u043d\u0435\u043d\u0438\u044f \u0441\u0442\u043e\u0440\u043e\u043d\u0430\u043c\u0438."}</span></p></div><div key={14} style={{
        position: "absolute",
        left: "66.4484vw",
        top: "22.9347vh",
        width: "28.8687vw",
        height: "36.6556vh",
        boxSizing: "border-box",
        backgroundColor: "#ffffff",
        border: "1.06px solid #dde4eb",
        borderRadius: "43.99px",
        boxShadow: "0px 2.42px 4.2px rgba(0, 0, 0, 0.35)"
      }} /><div key={15} style={{
        position: "absolute",
        left: "66.5258vw",
        top: "25.3333vh",
        width: "0.4078vw",
        height: "31.8583vh",
        boxSizing: "border-box",
        backgroundColor: "#d99137",
        boxShadow: "0px 2.42px 4.2px rgba(0, 0, 0, 0.35)"
      }} /><div key={16} style={{
        position: "absolute",
        left: "68.25vw",
        top: "25.3333vh",
        width: "25.7188vw",
        height: "4.5778vh",
        boxSizing: "border-box",
        backgroundColor: "transparent",
        padding: "0.3986vh 0.2242vw 0.3986vh 0.2242vw",
        wordWrap: "break-word"
      }}><p style={{
          lineHeight: "1.2",
          fontSize: "1.7708vw",
          marginTop: "0",
          marginBottom: "0"
        }}><span style={{
            fontSize: "1.7708vw",
            fontFamily: "'Aptos', sans-serif",
            fontWeight: "700",
            color: "#14263d",
            letterSpacing: "-0.01pt"
          }}>{"\u0411\u0430\u0437\u0430 \u0440\u0430\u0441\u0447\u0451\u0442\u0430"}</span></p></div><div key={17} style={{
        position: "absolute",
        left: "68.25vw",
        top: "31.2028vh",
        width: "25.568vw",
        height: "13.2333vh",
        boxSizing: "border-box",
        backgroundColor: "transparent",
        padding: "0.3986vh 0.2242vw 0.3986vh 0.2242vw",
        wordWrap: "break-word"
      }}><p style={{
          lineHeight: "1.2",
          fontSize: "1.5vw",
          marginTop: "0",
          marginBottom: "0"
        }}><span style={{
            fontSize: "1.5vw",
            fontFamily: "'Aptos', sans-serif",
            color: "#243447",
            letterSpacing: "-0.01pt"
          }}>{"\u041d\u0443\u0436\u043d\u043e \u0441\u043e\u0433\u043b\u0430\u0441\u043e\u0432\u0430\u0442\u044c \u0431\u0430\u0437\u0443, \u043c\u043e\u043c\u0435\u043d\u0442 \u043d\u0430\u0447\u0438\u0441\u043b\u0435\u043d\u0438\u044f, \u0432\u043e\u0437\u0432\u0440\u0430\u0442\u044b \u0438 \u0441\u0440\u043e\u043a\u0438 \u0432\u044b\u043f\u043b\u0430\u0442."}</span></p></div><div key={18} style={{
        position: "absolute",
        left: "6.375vw",
        top: "62.3986vh",
        width: "86.2469vw",
        height: "3.5694vh",
        boxSizing: "border-box",
        backgroundColor: "transparent",
        padding: "0.3986vh 0.2242vw 0.3986vh 0.2242vw",
        wordWrap: "break-word"
      }}><p style={{
          textAlign: "center",
          lineHeight: "1.2",
          fontSize: "1.5vw",
          marginTop: "0",
          marginBottom: "0"
        }}><span style={{
            fontSize: "1.5vw",
            fontFamily: "'Aptos', sans-serif",
            color: "#4d6073",
            letterSpacing: "-0.01pt"
          }}>{"\u0421\u0430\u0439\u0442 \u043d\u0435 \u0440\u0430\u0441\u0441\u0447\u0438\u0442\u044b\u0432\u0430\u0435\u0442 \u0438 \u043d\u0435 \u043f\u0435\u0440\u0435\u0432\u043e\u0434\u0438\u0442 \u043a\u043e\u043c\u0438\u0441\u0441\u0438\u044e \u0430\u0432\u0442\u043e\u043c\u0430\u0442\u0438\u0447\u0435\u0441\u043a\u0438."}</span></p></div><img key={19} src={img_1} crossOrigin="anonymous" alt="Условия размещения для продавцов" style={{
        position: "absolute",
        left: "18.2453vw",
        top: "67.1917vh",
        width: "62.0695vw",
        height: "25.1972vh",
        boxSizing: "border-box",
        objectFit: "fill"
      }} /><img key={20} src={img_2} crossOrigin="anonymous" alt="Главная страница каталога" style={{
        position: "absolute",
        left: "17.7164vw",
        top: "67.1917vh",
        width: "62.0695vw",
        height: "25.1972vh",
        boxSizing: "border-box",
        objectFit: "fill"
      }} /></div>;
};
export default Slide8;
