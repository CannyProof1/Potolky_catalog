import React from "react";
const Slide1: React.FC = () => {
  return <div id="slide-1" className="w-screen h-screen overflow-hidden relative" style={{backgroundColor:"#000"}}><div key={0} style={{
        position: "absolute",
        left: "0vw",
        top: "0vh",
        width: "99.9922vw",
        height: "99.9889vh",
        boxSizing: "border-box",
        backgroundColor: "#14263d",
        boxShadow: "0px 2.42px 4.2px rgba(0, 0, 0, 0.35)"
      }} /><div key={1} style={{
        position: "absolute",
        left: "0vw",
        top: "0vh",
        width: "1.193vw",
        height: "99.9889vh",
        boxSizing: "border-box",
        backgroundColor: "#1f9f8b",
        boxShadow: "0px 2.42px 4.2px rgba(0, 0, 0, 0.35)"
      }} /><div key={2} style={{
        position: "absolute",
        left: "6.375vw",
        top: "9.6014vh",
        width: "81.7437vw",
        height: "3.6847vh",
        boxSizing: "border-box",
        backgroundColor: "transparent",
        padding: "0.3986vh 0.2242vw 0.3986vh 0.2242vw",
        wordWrap: "break-word"
      }}><p style={{
          lineHeight: "1.2",
          fontSize: "1.5vw",
          marginTop: "0",
          marginBottom: "0"
        }}><span style={{
            fontSize: "1.5vw",
            fontFamily: "'Aptos', sans-serif",
            fontWeight: "700",
            color: "#77decb",
            letterSpacing: "-0.01pt"
          }}>{"\u0414\u0418\u041F\u041B\u041E\u041C\u041D\u042B\u0419 \u041F\u0420\u041E\u0415\u041A\u0422 \u2022 2026"}</span></p></div><div key={3} style={{
        position: "absolute",
        left: "6.375vw",
        top: "19.0653vh",
        width: "87.7437vw",
        height: "8.3514vh",
        boxSizing: "border-box",
        backgroundColor: "transparent",
        padding: "0.3986vh 0.2242vw 0.3986vh 0.2242vw",
        wordWrap: "break-word"
      }}><p style={{
          lineHeight: "1.2",
          fontSize: "3.5417vw",
          marginTop: "0",
          marginBottom: "0"
        }}><span style={{
            fontSize: "3.5417vw",
            fontFamily: "'Aptos', sans-serif",
            fontWeight: "700",
            color: "#ffffff",
            letterSpacing: "-0.01pt"
          }}>{"\u0421\u0430\u0439\u0442-\u043A\u0430\u0442\u0430\u043B\u043E\u0433 \u043D\u0430\u0442\u044F\u0436\u043D\u044B\u0445 \u043F\u043E\u0442\u043E\u043B\u043A\u043E\u0432"}</span></p></div><div key={4} style={{
        position: "absolute",
        left: "6.5992vw",
        top: "41.6014vh",
        width: "80.9937vw",
        height: "5.0181vh",
        boxSizing: "border-box",
        backgroundColor: "transparent",
        padding: "0.3986vh 0.2242vw 0.3986vh 0.2242vw",
        wordWrap: "break-word"
      }}><p style={{
          lineHeight: "1.2",
          fontSize: "1.9792vw",
          marginTop: "0",
          marginBottom: "0"
        }}><span style={{
            fontSize: "1.9792vw",
            fontFamily: "'Aptos', sans-serif",
            color: "#d8e2ed",
            letterSpacing: "-0.01pt"
          }}>{"\u041a\u0430\u0442\u0430\u043b\u043e\u0433 \u0442\u043e\u0432\u0430\u0440\u043e\u0432, \u0440\u0435\u0433\u0438\u0441\u0442\u0440\u0430\u0446\u0438\u044f, \u043c\u043e\u0434\u0435\u0440\u0430\u0446\u0438\u044f \u0438 \u0437\u0430\u044f\u0432\u043a\u0438 \u0431\u0435\u0437 \u043e\u043f\u043b\u0430\u0442\u044b"}</span></p></div><div key={5} style={{
        position: "absolute",
        left: "6.5992vw",
        top: "57.3333vh",
        width: "9.3688vw",
        height: "5.7222vh",
        boxSizing: "border-box",
        backgroundColor: "#1d3752",
        border: "1.06px solid #1d3752",
        borderRadius: "6.87px",
        boxShadow: "0px 2.42px 4.2px rgba(0, 0, 0, 0.35)"
      }} /><div key={6} style={{
        position: "absolute",
        left: "6.5992vw",
        top: "58.2681vh",
        width: "9.3688vw",
        height: "3.0125vh",
        boxSizing: "border-box",
        backgroundColor: "transparent",
        padding: "0.3986vh 0.2242vw 0.3986vh 0.2242vw",
        wordWrap: "break-word"
      }}><p style={{
          textAlign: "center",
          lineHeight: "1.2",
          fontSize: "1.5vw",
          marginTop: "0",
          marginBottom: "0"
        }}><span style={{
            fontSize: "1.5vw",
            fontFamily: "'Aptos', sans-serif",
            fontWeight: "700",
            color: "#ffffff",
            letterSpacing: "-0.01pt"
          }}>{"REACT"}</span></p></div><div key={7} style={{
        position: "absolute",
        left: "17.1766vw",
        top: "57.3333vh",
        width: "7.4938vw",
        height: "5.7222vh",
        boxSizing: "border-box",
        backgroundColor: "#1d3752",
        border: "1.06px solid #1d3752",
        borderRadius: "6.87px",
        boxShadow: "0px 2.42px 4.2px rgba(0, 0, 0, 0.35)"
      }} /><div key={8} style={{
        position: "absolute",
        left: "17.1766vw",
        top: "58.2681vh",
        width: "7.4938vw",
        height: "3.0125vh",
        boxSizing: "border-box",
        backgroundColor: "transparent",
        padding: "0.3986vh 0.2242vw 0.3986vh 0.2242vw",
        wordWrap: "break-word"
      }}><p style={{
          textAlign: "center",
          lineHeight: "1.2",
          fontSize: "1.5vw",
          marginTop: "0",
          marginBottom: "0"
        }}><span style={{
            fontSize: "1.5vw",
            fontFamily: "'Aptos', sans-serif",
            fontWeight: "700",
            color: "#ffffff",
            letterSpacing: "-0.01pt"
          }}>{"EXPRESS"}</span></p></div><div key={9} style={{
        position: "absolute",
        left: "25.875vw",
        top: "57.3333vh",
        width: "12.8945vw",
        height: "5.7222vh",
        boxSizing: "border-box",
        backgroundColor: "#1d3752",
        border: "1.06px solid #1d3752",
        borderRadius: "6.87px",
        boxShadow: "0px 2.42px 4.2px rgba(0, 0, 0, 0.35)"
      }} /><div key={10} style={{
        position: "absolute",
        left: "25.875vw",
        top: "58.2681vh",
        width: "12.8945vw",
        height: "3.0125vh",
        boxSizing: "border-box",
        backgroundColor: "transparent",
        padding: "0.3986vh 0.2242vw 0.3986vh 0.2242vw",
        wordWrap: "break-word"
      }}><p style={{
          textAlign: "center",
          lineHeight: "1.2",
          fontSize: "1.5vw",
          marginTop: "0",
          marginBottom: "0"
        }}><span style={{
            fontSize: "1.5vw",
            fontFamily: "'Aptos', sans-serif",
            fontWeight: "700",
            color: "#ffffff",
            letterSpacing: "-0.01pt"
          }}>{"POSTGRESQL"}</span></p></div><div key={11} style={{
        position: "absolute",
        left: "39.9742vw",
        top: "57.3333vh",
        width: "11.9938vw",
        height: "5.7222vh",
        boxSizing: "border-box",
        backgroundColor: "#1d3752",
        border: "1.06px solid #1d3752",
        borderRadius: "6.87px",
        boxShadow: "0px 2.42px 4.2px rgba(0, 0, 0, 0.35)"
      }} /><div key={12} style={{
        position: "absolute",
        left: "39.9742vw",
        top: "58.2681vh",
        width: "11.9938vw",
        height: "3.0125vh",
        boxSizing: "border-box",
        backgroundColor: "transparent",
        padding: "0.3986vh 0.2242vw 0.3986vh 0.2242vw",
        wordWrap: "break-word"
      }}><p style={{
          textAlign: "center",
          lineHeight: "1.2",
          fontSize: "1.5vw",
          marginTop: "0",
          marginBottom: "0"
        }}><span style={{
            fontSize: "1.5vw",
            fontFamily: "'Aptos', sans-serif",
            fontWeight: "700",
            color: "#ffffff",
            letterSpacing: "-0.01pt"
          }}>{"CLERK"}</span></p></div><div key={13} style={{
        position: "absolute",
        left: "6.4961vw",
        top: "71.2444vh",
        width: "44.9937vw",
        height: "4.3458vh",
        boxSizing: "border-box",
        backgroundColor: "transparent",
        padding: "0.3986vh 0.2242vw 0.3986vh 0.2242vw",
        wordWrap: "break-word"
      }}><p style={{
          lineHeight: "1.2",
          fontSize: "1.6667vw",
          marginTop: "0",
          marginBottom: "0"
        }}><span style={{
            fontSize: "1.6667vw",
            fontFamily: "'Aptos', sans-serif",
            fontWeight: "700",
            color: "#ffffff",
            letterSpacing: "-0.01pt"
          }}>{"\u0412\u044B\u043F\u043E\u043B\u043D\u0438\u043B: \u041C\u0430\u0442\u0432\u0435\u0439 \u041D\u0430\u043C\u0430\u0437\u043E\u0432"}</span></p></div><div key={14} style={{
        position: "absolute",
        left: "6.4961vw",
        top: "83.5958vh",
        width: "56.2437vw",
        height: "3.6847vh",
        boxSizing: "border-box",
        backgroundColor: "transparent",
        padding: "0.3986vh 0.2242vw 0.3986vh 0.2242vw",
        wordWrap: "break-word"
      }}><p style={{
          lineHeight: "1.2",
          fontSize: "1.5vw",
          marginTop: "0",
          marginBottom: "0"
        }}><span style={{
            fontSize: "1.5vw",
            fontFamily: "'Aptos', sans-serif",
            color: "#cdd9e6",
            letterSpacing: "-0.01pt"
          }}>{"\u0418\u043D\u0442\u0435\u0440\u0444\u0435\u0439\u0441 React \u2022 API Express \u2022 \u0431\u0430\u0437\u0430 PostgreSQL"}</span><span style={{
            fontSize: "1.5vw",
            fontFamily: "'Aptos', sans-serif",
            color: "#cdd9e6",
            letterSpacing: "-0.01pt"
          }}>{""}</span></p></div><div key={15} style={{
        position: "absolute",
        left: "80.25vw",
        top: "91.0653vh",
        width: "13.1187vw",
        height: "3.0125vh",
        boxSizing: "border-box",
        backgroundColor: "transparent",
        padding: "0.3986vh 0.2242vw 0.3986vh 0.2242vw",
        wordWrap: "break-word"
      }}><p style={{
          textAlign: "right",
          lineHeight: "1.2",
          fontSize: "1.5vw",
          marginTop: "0",
          marginBottom: "0"
        }}><span style={{
            fontSize: "1.5vw",
            fontFamily: "'Aptos', sans-serif",
            color: "#a2b4c5",
            letterSpacing: "-0.01pt"
          }}>{"01 / 11"}</span></p></div><div key={16} style={{
        position: "absolute",
        left: "5.9055vw",
        top: "76.6403vh",
        width: "28.0336vw",
        height: "5.4806vh",
        boxSizing: "border-box",
        backgroundColor: "transparent",
        padding: "0.6556vh 0.7383vw 0.6556vh 0.7383vw",
        wordWrap: "break-word"
      }}><p style={{
          lineHeight: "1.2",
          fontSize: "1.6667vw",
          marginTop: "0",
          marginBottom: "0"
        }}><span style={{
            fontSize: "1.6667vw",
            fontFamily: "'Aptos', sans-serif",
            fontWeight: "700",
            color: "#ffffff",
            letterSpacing: "-0.01pt"
          }}>{"\u0423\u0447\u0438\u0442\u0435\u043B\u044C: \u0414\u0435\u043C\u0435\u043D\u0442\u044C\u0435\u0432 \u0410. \u0415 "}</span></p></div></div>;
};
export default Slide1;
