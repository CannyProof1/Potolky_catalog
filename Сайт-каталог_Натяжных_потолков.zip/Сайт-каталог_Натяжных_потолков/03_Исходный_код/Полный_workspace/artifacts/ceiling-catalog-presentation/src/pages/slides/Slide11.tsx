import React from "react";
const Slide11: React.FC = () => {
  return <div id="slide-11" className="w-screen h-screen overflow-hidden relative" style={{backgroundColor:"#000"}}><div key={0} style={{
        position: "absolute",
        left: "0vw",
        top: "0vh",
        width: "99.9922vw",
        height: "99.9889vh",
        boxSizing: "border-box",
        backgroundColor: "#f7f9fb",
        boxShadow: "0px 2.42px 4.2px rgba(0, 0, 0, 0.35)"
      }} /><div key={1} style={{
        position: "absolute",
        left: "4.6508vw",
        top: "4.5361vh",
        width: "90.3687vw",
        height: "3.0181vh",
        boxSizing: "border-box",
        backgroundColor: "transparent",
        padding: "0.3986vh 0.2242vw 0.3986vh 0.2242vw",
        wordWrap: "break-word"
      }}><p style={{
          lineHeight: "1.2",
          fontSize: "1.5vw",
          marginTop: "0",
          marginBottom: "0"
        }}><span style={{
            fontSize: "1.5vw",
            fontFamily: "'Aptos', sans-serif",
            fontWeight: "700",
            color: "#1f9f8b",
            letterSpacing: "-0.01pt"
          }}>{"10 \u2022 \u0417\u0410\u0412\u0415\u0420\u0428\u0415\u041D\u0418\u0415"}</span></p></div><div key={2} style={{
        position: "absolute",
        left: "4.6508vw",
        top: "9.2028vh",
        width: "90.3687vw",
        height: "6.8028vh",
        boxSizing: "border-box",
        backgroundColor: "transparent",
        padding: "0.3986vh 0.2242vw 0.3986vh 0.2242vw",
        wordWrap: "break-word"
      }}><p style={{
          lineHeight: "1.2",
          fontSize: "2.8125vw",
          marginTop: "0",
          marginBottom: "0"
        }}><span style={{
            fontSize: "2.8125vw",
            fontFamily: "'Aptos', sans-serif",
            fontWeight: "700",
            color: "#14263d",
            letterSpacing: "-0.01pt"
          }}>{"\u041f\u0440\u043e\u0435\u043a\u0442 \u0433\u043e\u0442\u043e\u0432 \u043a \u0437\u0430\u043f\u043e\u043b\u043d\u0435\u043d\u0438\u044e \u0440\u0435\u0430\u043b\u044c\u043d\u044b\u043c\u0438 \u0434\u0430\u043d\u043d\u044b\u043c\u0438"}</span></p></div><div key={3} style={{
        position: "absolute",
        left: "4.6508vw",
        top: "18.3986vh",
        width: "90.3687vw",
        height: "0.325vh",
        boxSizing: "border-box",
        backgroundColor: "#dde4eb",
        boxShadow: "0px 2.42px 4.2px rgba(0, 0, 0, 0.35)"
      }} /><div key={4} style={{
        position: "absolute",
        left: "4.6508vw",
        top: "94.9347vh",
        width: "73.4938vw",
        height: "2.7931vh",
        boxSizing: "border-box",
        backgroundColor: "transparent",
        padding: "0.3986vh 0.2242vw 0.3986vh 0.2242vw",
        wordWrap: "break-word"
      }}><p style={{
          lineHeight: "1.2",
          fontSize: "1.5vw",
          marginTop: "0",
          marginBottom: "0"
        }}><span style={{
            fontSize: "1.5vw",
            fontFamily: "'Aptos', sans-serif",
            color: "#617182",
            letterSpacing: "-0.01pt"
          }}>{"\u0414\u0438\u043f\u043b\u043e\u043c\u043d\u044b\u0439 \u043f\u0440\u043e\u0435\u043a\u0442 \u2022 \u041c\u0430\u0442\u0432\u0435\u0439 \u041d\u0430\u043c\u0430\u0437\u043e\u0432 \u2022 \u0421\u0430\u0439\u0442-\u043a\u0430\u0442\u0430\u043b\u043e\u0433 \u043d\u0430\u0442\u044f\u0436\u043d\u044b\u0445 \u043f\u043e\u0442\u043e\u043b\u043a\u043e\u0432"}</span></p></div><div key={5} style={{
        position: "absolute",
        left: "87.9008vw",
        top: "94.6667vh",
        width: "7.1188vw",
        height: "2.7931vh",
        boxSizing: "border-box",
        backgroundColor: "transparent",
        padding: "0.3986vh 0.2242vw 0.3986vh 0.2242vw",
        wordWrap: "break-word"
      }}><p style={{
          textAlign: "right",
          lineHeight: "1.2",
          fontSize: "1.5vw",
          marginTop: "0",
          marginBottom: "0"
        }}><span style={{
            fontSize: "1.5vw",
            fontFamily: "'Aptos', sans-serif",
            color: "#617182",
            letterSpacing: "-0.01pt"
          }}>{"11 / 11"}</span></p></div><div key={6} style={{
        position: "absolute",
        left: "6.1508vw",
        top: "22.2681vh",
        width: "87.3687vw",
        height: "8.3625vh",
        boxSizing: "border-box",
        backgroundColor: "transparent",
        padding: "0.3986vh 0.2242vw 0.3986vh 0.2242vw",
        wordWrap: "break-word"
      }}><p style={{
          textAlign: "center",
          lineHeight: "1.2",
          fontSize: "1.7708vw",
          marginTop: "0",
          marginBottom: "0"
        }}><span style={{
            fontSize: "1.7708vw",
            fontFamily: "'Aptos', sans-serif",
            color: "#243447",
            letterSpacing: "-0.01pt"
          }}>{"\u041f\u0443\u0442\u044c \u0442\u043e\u0432\u0430\u0440\u0430: \u043a\u0430\u0440\u0442\u043e\u0447\u043a\u0430 \u043f\u0440\u043e\u0434\u0430\u0432\u0446\u0430 \u2192 \u043f\u0440\u043e\u0432\u0435\u0440\u043a\u0430 \u0430\u0434\u043c\u0438\u043d\u0438\u0441\u0442\u0440\u0430\u0442\u043e\u0440\u043e\u043c \u2192 \u043f\u0443\u0431\u043b\u0438\u043a\u0430\u0446\u0438\u044f \u0432 \u043a\u0430\u0442\u0430\u043b\u043e\u0433\u0435."}</span></p></div><div key={7} style={{
        position: "absolute",
        left: "10.8039vw",
        top: "40.9444vh",
        width: "78.3687vw",
        height: "7.0556vh",
        boxSizing: "border-box",
        backgroundColor: "#ffffff",
        border: "1.06px solid #dde4eb",
        borderRadius: "8.47px",
        boxShadow: "0px 2.42px 4.2px rgba(0, 0, 0, 0.35)"
      }} /><div key={8} style={{
        position: "absolute",
        left: "12.5289vw",
        top: "42.6778vh",
        width: "24.7438vw",
        height: "3.6792vh",
        boxSizing: "border-box",
        backgroundColor: "transparent",
        padding: "0.3986vh 0.2242vw 0.3986vh 0.2242vw",
        wordWrap: "break-word"
      }}><p style={{
          lineHeight: "1.2",
          fontSize: "1.5vw",
          marginTop: "0",
          marginBottom: "0"
        }}><span style={{
            fontSize: "1.5vw",
            fontFamily: "'Aptos', sans-serif",
            fontWeight: "700",
            color: "#14263d",
            letterSpacing: "-0.01pt"
          }}>{"\u041a\u0430\u0442\u0430\u043b\u043e\u0433 \u0438 \u0437\u0430\u044f\u0432\u043a\u0438 \u0431\u0435\u0437 \u043e\u043d\u043b\u0430\u0439\u043d-\u043e\u043f\u043b\u0430\u0442\u044b"}</span></p></div><div key={9} style={{
        position: "absolute",
        left: "38.5539vw",
        top: "42.6778vh",
        width: "48.3687vw",
        height: "3.5806vh",
        boxSizing: "border-box",
        backgroundColor: "transparent",
        padding: "0.3986vh 0.2242vw 0.3986vh 0.2242vw",
        wordWrap: "break-word"
      }}><p style={{
          lineHeight: "1.2",
          fontSize: "1.5vw",
          marginTop: "0",
          marginBottom: "0"
        }}><span style={{
            fontSize: "1.5vw",
            fontFamily: "'Aptos', sans-serif",
            color: "#6b7d8f",
            letterSpacing: "-0.01pt"
          }}>{"Работа сайта доступна в Replit Preview"}</span></p></div><div key={10} style={{
        position: "absolute",
        left: "10.6297vw",
        top: "50.6875vh",
        width: "78.3687vw",
        height: "7.0556vh",
        boxSizing: "border-box",
        backgroundColor: "#ffffff",
        border: "1.06px solid #dde4eb",
        borderRadius: "8.47px",
        boxShadow: "0px 2.42px 4.2px rgba(0, 0, 0, 0.35)"
      }} /><div key={11} style={{
        position: "absolute",
        left: "12.3547vw",
        top: "52.425vh",
        width: "24.7438vw",
        height: "3.6792vh",
        boxSizing: "border-box",
        backgroundColor: "transparent",
        padding: "0.3986vh 0.2242vw 0.3986vh 0.2242vw",
        wordWrap: "break-word"
      }}><p style={{
          lineHeight: "1.2",
          fontSize: "1.5vw",
          marginTop: "0",
          marginBottom: "0"
        }}><span style={{
            fontSize: "1.5vw",
            fontFamily: "'Aptos', sans-serif",
            fontWeight: "700",
            color: "#14263d",
            letterSpacing: "-0.01pt"
          }}>{"\u0420\u0435\u0433\u0438\u0441\u0442\u0440\u0430\u0446\u0438\u044f, \u043a\u0430\u0431\u0438\u043d\u0435\u0442\u044b \u0438 \u043f\u043e\u0434\u0434\u0435\u0440\u0436\u043a\u0430"}</span></p></div><div key={12} style={{
        position: "absolute",
        left: "38.3797vw",
        top: "52.425vh",
        width: "48.3687vw",
        height: "3.4639vh",
        boxSizing: "border-box",
        backgroundColor: "transparent",
        padding: "0.3986vh 0.2242vw 0.3986vh 0.2242vw",
        wordWrap: "break-word"
      }}><p style={{
          lineHeight: "1.2",
          fontSize: "1.5vw",
          marginTop: "0",
          marginBottom: "0"
        }}><span style={{
            fontSize: "1.5vw",
            fontFamily: "'Aptos', sans-serif",
            color: "#6b7d8f",
            letterSpacing: "-0.01pt"
          }}>{"Административная панель доступна после входа"}</span></p></div><div key={13} style={{
        position: "absolute",
        left: "6.1508vw",
        top: "71.3917vh",
        width: "87.3687vw",
        height: "4.2472vh",
        boxSizing: "border-box",
        backgroundColor: "transparent",
        padding: "0.3986vh 0.2242vw 0.3986vh 0.2242vw",
        wordWrap: "break-word"
      }}><p style={{
          textAlign: "center",
          lineHeight: "1.2",
          fontSize: "1.6146vw",
          marginTop: "0",
          marginBottom: "0"
        }}><span style={{
            fontSize: "1.6146vw",
            fontFamily: "'Aptos', sans-serif",
            color: "#243447",
            letterSpacing: "-0.01pt"
          }}>{"\u0421\u043f\u0430\u0441\u0438\u0431\u043e. \u0413\u043e\u0442\u043e\u0432 \u043f\u043e\u043a\u0430\u0437\u0430\u0442\u044c \u0440\u0430\u0431\u043e\u0442\u0443 \u0441\u0430\u0439\u0442\u0430 \u0438 \u043e\u0442\u0432\u0435\u0442\u0438\u0442\u044c \u043d\u0430 \u0432\u043e\u043f\u0440\u043e\u0441\u044b."}</span></p></div></div>;
};
export default Slide11;
