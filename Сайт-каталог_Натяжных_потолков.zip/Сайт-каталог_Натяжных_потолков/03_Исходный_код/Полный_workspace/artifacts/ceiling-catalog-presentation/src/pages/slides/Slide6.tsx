import React from "react";
const Slide6: React.FC = () => {
  return <div id="slide-6" className="w-screen h-screen overflow-hidden relative" style={{backgroundColor:"#000"}}><div key={0} style={{
        position: "absolute",
        left: "0vw",
        top: "0vh",
        width: "99.9922vw",
        height: "99.9889vh",
        boxSizing: "border-box",
        backgroundColor: "#f7f9fb",
        boxShadow: "0px 2.42px 4.2px rgba(0, 0, 0, 0.35)"
      }} /><div key={1} style={{
        position: "absolute",
        left: "4.6508vw",
        top: "4.5361vh",
        width: "90.3687vw",
        height: "3.0181vh",
        boxSizing: "border-box",
        backgroundColor: "transparent",
        padding: "0.3986vh 0.2242vw 0.3986vh 0.2242vw",
        wordWrap: "break-word"
      }}><p style={{
          lineHeight: "1.2",
          fontSize: "1.5vw",
          marginTop: "0",
          marginBottom: "0"
        }}><span style={{
            fontSize: "1.5vw",
            fontFamily: "'Aptos', sans-serif",
            fontWeight: "700",
            color: "#1f9f8b",
            letterSpacing: "-0.01pt"
          }}>{"05 \u2022 \u041A\u0410\u0422\u0410\u041B\u041E\u0413"}</span></p></div><div key={2} style={{
        position: "absolute",
        left: "4.6508vw",
        top: "9.2028vh",
        width: "90.3687vw",
        height: "7.0181vh",
        boxSizing: "border-box",
        backgroundColor: "transparent",
        padding: "0.3986vh 0.2242vw 0.3986vh 0.2242vw",
        wordWrap: "break-word"
      }}><p style={{
          lineHeight: "1.2",
          fontSize: "2.9167vw",
          marginTop: "0",
          marginBottom: "0"
        }}><span style={{
            fontSize: "2.9167vw",
            fontFamily: "'Aptos', sans-serif",
            fontWeight: "700",
            color: "#14263d",
            letterSpacing: "-0.01pt"
          }}>{"\u041D\u043E\u0432\u0430\u044F \u043A\u0430\u0440\u0442\u043E\u0447\u043A\u0430 \u043F\u0440\u043E\u0445\u043E\u0434\u0438\u0442 \u043F\u0440\u043E\u0432\u0435\u0440\u043A\u0443"}</span></p></div><div key={3} style={{
        position: "absolute",
        left: "4.6508vw",
        top: "18.3986vh",
        width: "90.3687vw",
        height: "0.325vh",
        boxSizing: "border-box",
        backgroundColor: "#dde4eb",
        boxShadow: "0px 2.42px 4.2px rgba(0, 0, 0, 0.35)"
      }} /><div key={4} style={{
        position: "absolute",
        left: "4.6508vw",
        top: "94.9347vh",
        width: "73.4938vw",
        height: "2.7931vh",
        boxSizing: "border-box",
        backgroundColor: "transparent",
        padding: "0.3986vh 0.2242vw 0.3986vh 0.2242vw",
        wordWrap: "break-word"
      }}><p style={{
          lineHeight: "1.2",
          fontSize: "1.5vw",
          marginTop: "0",
          marginBottom: "0"
        }}><span style={{
            fontSize: "1.5vw",
            fontFamily: "'Aptos', sans-serif",
            color: "#617182",
            letterSpacing: "-0.01pt"
          }}>{"\u0414\u0438\u043f\u043b\u043e\u043c\u043d\u044b\u0439 \u043f\u0440\u043e\u0435\u043a\u0442 \u2022 \u041c\u0430\u0442\u0432\u0435\u0439 \u041d\u0430\u043c\u0430\u0437\u043e\u0432 \u2022 \u0421\u0430\u0439\u0442-\u043a\u0430\u0442\u0430\u043b\u043e\u0433 \u043d\u0430\u0442\u044f\u0436\u043d\u044b\u0445 \u043f\u043e\u0442\u043e\u043b\u043a\u043e\u0432"}</span></p></div><div key={5} style={{
        position: "absolute",
        left: "87.9008vw",
        top: "94.6667vh",
        width: "7.1188vw",
        height: "2.7931vh",
        boxSizing: "border-box",
        backgroundColor: "transparent",
        padding: "0.3986vh 0.2242vw 0.3986vh 0.2242vw",
        wordWrap: "break-word"
      }}><p style={{
          textAlign: "right",
          lineHeight: "1.2",
          fontSize: "1.5vw",
          marginTop: "0",
          marginBottom: "0"
        }}><span style={{
            fontSize: "1.5vw",
            fontFamily: "'Aptos', sans-serif",
            color: "#617182",
            letterSpacing: "-0.01pt"
          }}>{"06 / 11"}</span></p></div><div key={6} style={{
        position: "absolute",
        left: "4.6508vw",
        top: "25.3333vh",
        width: "20.7695vw",
        height: "31.7222vh",
        boxSizing: "border-box",
        backgroundColor: "#ffffff",
        border: "1.06px solid #dde4eb",
        borderRadius: "38.07px",
        boxShadow: "0px 2.42px 4.2px rgba(0, 0, 0, 0.35)"
      }} /><div key={7} style={{
        position: "absolute",
        left: "6.1508vw",
        top: "28.2681vh",
        width: "3.443vw",
        height: "5.6847vh",
        boxSizing: "border-box",
        backgroundColor: "transparent",
        padding: "0.3986vh 0.2242vw 0.3986vh 0.2242vw",
        wordWrap: "break-word"
      }}><p style={{
          lineHeight: "1.2",
          fontSize: "2.2917vw",
          marginTop: "0",
          marginBottom: "0"
        }}><span style={{
            fontSize: "2.2917vw",
            fontFamily: "'Aptos', sans-serif",
            fontWeight: "700",
            color: "#1f9f8b",
            letterSpacing: "-0.01pt"
          }}>{"1"}</span></p></div><div key={8} style={{
        position: "absolute",
        left: "6.1508vw",
        top: "36.3986vh",
        width: "17.5453vw",
        height: "4.5833vh",
        boxSizing: "border-box",
        backgroundColor: "transparent",
        padding: "0.3986vh 0.2242vw 0.3986vh 0.2242vw",
        wordWrap: "break-word"
      }}><p style={{
          lineHeight: "1.2",
          fontSize: "1.7708vw",
          marginTop: "0",
          marginBottom: "0"
        }}><span style={{
            fontSize: "1.7708vw",
            fontFamily: "'Aptos', sans-serif",
            fontWeight: "700",
            color: "#14263d",
            letterSpacing: "-0.01pt"
          }}>{"\u0417\u0430\u043F\u043E\u043B\u043D\u0438\u0442\u044C"}</span></p></div><div key={9} style={{
        position: "absolute",
        left: "6.1508vw",
        top: "43.3333vh",
        width: "17.693vw",
        height: "10.1264vh",
        boxSizing: "border-box",
        backgroundColor: "transparent",
        padding: "0.3986vh 0.2242vw 0.3986vh 0.2242vw",
        wordWrap: "break-word"
      }}><p style={{
          lineHeight: "1.2",
          fontSize: "1.5vw",
          marginTop: "0",
          marginBottom: "0"
        }}><span style={{
            fontSize: "1.5vw",
            fontFamily: "'Aptos', sans-serif",
            color: "#243447",
            letterSpacing: "-0.01pt"
          }}>{"\u041f\u0440\u043e\u0434\u0430\u0432\u0435\u0446 \u0434\u043e\u0431\u0430\u0432\u043b\u044f\u0435\u0442 \u043d\u0430\u0437\u0432\u0430\u043d\u0438\u0435, \u0446\u0435\u043d\u0443 \u0438 \u0445\u0430\u0440\u0430\u043a\u0442\u0435\u0440\u0438\u0441\u0442\u0438\u043a\u0438 \u0442\u043e\u0432\u0430\u0440\u0430."}</span></p></div><div key={10} style={{
        position: "absolute",
        left: "25.4266vw",
        top: "37.7319vh",
        width: "2.2437vw",
        height: "5.0181vh",
        boxSizing: "border-box",
        backgroundColor: "transparent",
        padding: "0.3986vh 0.2242vw 0.3986vh 0.2242vw",
        wordWrap: "break-word"
      }}><p style={{
          textAlign: "center",
          lineHeight: "1.2",
          fontSize: "1.9792vw",
          marginTop: "0",
          marginBottom: "0"
        }}><span style={{
            fontSize: "1.9792vw",
            fontFamily: "'Aptos', sans-serif",
            fontWeight: "700",
            color: "#1f9f8b",
            letterSpacing: "-0.01pt"
          }}>{"\u2192"}</span></p></div><div key={11} style={{
        position: "absolute",
        left: "27.75vw",
        top: "25.3333vh",
        width: "20.7695vw",
        height: "31.7222vh",
        boxSizing: "border-box",
        backgroundColor: "#ffffff",
        border: "1.06px solid #dde4eb",
        borderRadius: "38.07px",
        boxShadow: "0px 2.42px 4.2px rgba(0, 0, 0, 0.35)"
      }} /><div key={12} style={{
        position: "absolute",
        left: "29.25vw",
        top: "28.2681vh",
        width: "3.443vw",
        height: "5.6847vh",
        boxSizing: "border-box",
        backgroundColor: "transparent",
        padding: "0.3986vh 0.2242vw 0.3986vh 0.2242vw",
        wordWrap: "break-word"
      }}><p style={{
          lineHeight: "1.2",
          fontSize: "2.2917vw",
          marginTop: "0",
          marginBottom: "0"
        }}><span style={{
            fontSize: "2.2917vw",
            fontFamily: "'Aptos', sans-serif",
            fontWeight: "700",
            color: "#1f9f8b",
            letterSpacing: "-0.01pt"
          }}>{"2"}</span></p></div><div key={13} style={{
        position: "absolute",
        left: "29.25vw",
        top: "36.3986vh",
        width: "17.5453vw",
        height: "4.5833vh",
        boxSizing: "border-box",
        backgroundColor: "transparent",
        padding: "0.3986vh 0.2242vw 0.3986vh 0.2242vw",
        wordWrap: "break-word"
      }}><p style={{
          lineHeight: "1.2",
          fontSize: "1.7708vw",
          marginTop: "0",
          marginBottom: "0"
        }}><span style={{
            fontSize: "1.7708vw",
            fontFamily: "'Aptos', sans-serif",
            fontWeight: "700",
            color: "#14263d",
            letterSpacing: "-0.01pt"
          }}>{"\u0421\u043A\u0440\u044B\u0442\u044C"}</span></p></div><div key={14} style={{
        position: "absolute",
        left: "29.25vw",
        top: "43.3333vh",
        width: "17.693vw",
        height: "7.0181vh",
        boxSizing: "border-box",
        backgroundColor: "transparent",
        padding: "0.3986vh 0.2242vw 0.3986vh 0.2242vw",
        wordWrap: "break-word"
      }}><p style={{
          lineHeight: "1.2",
          fontSize: "1.5vw",
          marginTop: "0",
          marginBottom: "0"
        }}><span style={{
            fontSize: "1.5vw",
            fontFamily: "'Aptos', sans-serif",
            color: "#243447",
            letterSpacing: "-0.01pt"
          }}>{"\u0414\u043E \u043F\u0440\u043E\u0432\u0435\u0440\u043A\u0438 \u043A\u0430\u0440\u0442\u043E\u0447\u043A\u0430 \u043D\u0435 \u043F\u043E\u043F\u0430\u0434\u0430\u0435\u0442 \u0432 \u043A\u0430\u0442\u0430\u043B\u043E\u0433."}</span></p></div><div key={15} style={{
        position: "absolute",
        left: "48.5258vw",
        top: "37.7319vh",
        width: "2.2437vw",
        height: "5.0181vh",
        boxSizing: "border-box",
        backgroundColor: "transparent",
        padding: "0.3986vh 0.2242vw 0.3986vh 0.2242vw",
        wordWrap: "break-word"
      }}><p style={{
          textAlign: "center",
          lineHeight: "1.2",
          fontSize: "1.9792vw",
          marginTop: "0",
          marginBottom: "0"
        }}><span style={{
            fontSize: "1.9792vw",
            fontFamily: "'Aptos', sans-serif",
            fontWeight: "700",
            color: "#1f9f8b",
            letterSpacing: "-0.01pt"
          }}>{"\u2192"}</span></p></div><div key={16} style={{
        position: "absolute",
        left: "50.8492vw",
        top: "25.3333vh",
        width: "20.7695vw",
        height: "31.7222vh",
        boxSizing: "border-box",
        backgroundColor: "#ffffff",
        border: "1.06px solid #dde4eb",
        borderRadius: "38.07px",
        boxShadow: "0px 2.42px 4.2px rgba(0, 0, 0, 0.35)"
      }} /><div key={17} style={{
        position: "absolute",
        left: "52.3492vw",
        top: "28.2681vh",
        width: "3.443vw",
        height: "5.6847vh",
        boxSizing: "border-box",
        backgroundColor: "transparent",
        padding: "0.3986vh 0.2242vw 0.3986vh 0.2242vw",
        wordWrap: "break-word"
      }}><p style={{
          lineHeight: "1.2",
          fontSize: "2.2917vw",
          marginTop: "0",
          marginBottom: "0"
        }}><span style={{
            fontSize: "2.2917vw",
            fontFamily: "'Aptos', sans-serif",
            fontWeight: "700",
            color: "#1f9f8b",
            letterSpacing: "-0.01pt"
          }}>{"3"}</span></p></div><div key={18} style={{
        position: "absolute",
        left: "52.3492vw",
        top: "36.3986vh",
        width: "17.5453vw",
        height: "4.5833vh",
        boxSizing: "border-box",
        backgroundColor: "transparent",
        padding: "0.3986vh 0.2242vw 0.3986vh 0.2242vw",
        wordWrap: "break-word"
      }}><p style={{
          lineHeight: "1.2",
          fontSize: "1.7708vw",
          marginTop: "0",
          marginBottom: "0"
        }}><span style={{
            fontSize: "1.7708vw",
            fontFamily: "'Aptos', sans-serif",
            fontWeight: "700",
            color: "#14263d",
            letterSpacing: "-0.01pt"
          }}>{"\u041F\u0440\u043E\u0432\u0435\u0440\u0438\u0442\u044C"}</span></p></div><div key={19} style={{
        position: "absolute",
        left: "52.3492vw",
        top: "43.3333vh",
        width: "17.693vw",
        height: "10.1264vh",
        boxSizing: "border-box",
        backgroundColor: "transparent",
        padding: "0.3986vh 0.2242vw 0.3986vh 0.2242vw",
        wordWrap: "break-word"
      }}><p style={{
          lineHeight: "1.2",
          fontSize: "1.5vw",
          marginTop: "0",
          marginBottom: "0"
        }}><span style={{
            fontSize: "1.5vw",
            fontFamily: "'Aptos', sans-serif",
            color: "#243447",
            letterSpacing: "-0.01pt"
          }}>{"\u0410\u0434\u043C\u0438\u043D\u0438\u0441\u0442\u0440\u0430\u0442\u043E\u0440 \u043E\u0434\u043E\u0431\u0440\u044F\u0435\u0442 \u0438\u043B\u0438 \u043E\u0442\u043A\u043B\u043E\u043D\u044F\u0435\u0442 \u0442\u043E\u0432\u0430\u0440."}</span></p></div><div key={20} style={{
        position: "absolute",
        left: "71.625vw",
        top: "37.7319vh",
        width: "2.2437vw",
        height: "5.0181vh",
        boxSizing: "border-box",
        backgroundColor: "transparent",
        padding: "0.3986vh 0.2242vw 0.3986vh 0.2242vw",
        wordWrap: "break-word"
      }}><p style={{
          textAlign: "center",
          lineHeight: "1.2",
          fontSize: "1.9792vw",
          marginTop: "0",
          marginBottom: "0"
        }}><span style={{
            fontSize: "1.9792vw",
            fontFamily: "'Aptos', sans-serif",
            fontWeight: "700",
            color: "#1f9f8b",
            letterSpacing: "-0.01pt"
          }}>{"\u2192"}</span></p></div><div key={21} style={{
        position: "absolute",
        left: "73.9484vw",
        top: "25.3333vh",
        width: "20.7695vw",
        height: "31.7222vh",
        boxSizing: "border-box",
        backgroundColor: "#ffffff",
        border: "1.06px solid #dde4eb",
        borderRadius: "38.07px",
        boxShadow: "0px 2.42px 4.2px rgba(0, 0, 0, 0.35)"
      }} /><div key={22} style={{
        position: "absolute",
        left: "75.4484vw",
        top: "28.2681vh",
        width: "3.443vw",
        height: "5.6847vh",
        boxSizing: "border-box",
        backgroundColor: "transparent",
        padding: "0.3986vh 0.2242vw 0.3986vh 0.2242vw",
        wordWrap: "break-word"
      }}><p style={{
          lineHeight: "1.2",
          fontSize: "2.2917vw",
          marginTop: "0",
          marginBottom: "0"
        }}><span style={{
            fontSize: "2.2917vw",
            fontFamily: "'Aptos', sans-serif",
            fontWeight: "700",
            color: "#1f9f8b",
            letterSpacing: "-0.01pt"
          }}>{"4"}</span></p></div><div key={23} style={{
        position: "absolute",
        left: "75.4484vw",
        top: "36.3986vh",
        width: "17.5453vw",
        height: "4.5833vh",
        boxSizing: "border-box",
        backgroundColor: "transparent",
        padding: "0.3986vh 0.2242vw 0.3986vh 0.2242vw",
        wordWrap: "break-word"
      }}><p style={{
          lineHeight: "1.2",
          fontSize: "1.7708vw",
          marginTop: "0",
          marginBottom: "0"
        }}><span style={{
            fontSize: "1.7708vw",
            fontFamily: "'Aptos', sans-serif",
            fontWeight: "700",
            color: "#14263d",
            letterSpacing: "-0.01pt"
          }}>{"\u041E\u043F\u0443\u0431\u043B\u0438\u043A\u043E\u0432\u0430\u0442\u044C"}</span></p></div><div key={24} style={{
        position: "absolute",
        left: "75.4484vw",
        top: "43.3333vh",
        width: "17.693vw",
        height: "10.1264vh",
        boxSizing: "border-box",
        backgroundColor: "transparent",
        padding: "0.3986vh 0.2242vw 0.3986vh 0.2242vw",
        wordWrap: "break-word"
      }}><p style={{
          lineHeight: "1.2",
          fontSize: "1.5vw",
          marginTop: "0",
          marginBottom: "0"
        }}><span style={{
            fontSize: "1.5vw",
            fontFamily: "'Aptos', sans-serif",
            color: "#243447",
            letterSpacing: "-0.01pt"
          }}>{"\u041A\u0430\u0442\u0430\u043B\u043E\u0433 \u043F\u043E\u043A\u0430\u0437\u044B\u0432\u0430\u0435\u0442 \u0442\u043E\u043B\u044C\u043A\u043E \u043E\u0434\u043E\u0431\u0440\u0435\u043D\u043D\u044B\u0435 \u043A\u0430\u0440\u0442\u043E\u0447\u043A\u0438."}</span></p></div><div key={25} style={{
        position: "absolute",
        left: "6.375vw",
        top: "60.6667vh",
        width: "86.2469vw",
        height: "3.5694vh",
        boxSizing: "border-box",
        backgroundColor: "transparent",
        padding: "0.3986vh 0.2242vw 0.3986vh 0.2242vw",
        wordWrap: "break-word"
      }}><p style={{
          textAlign: "center",
          lineHeight: "1.2",
          fontSize: "1.5vw",
          marginTop: "0",
          marginBottom: "0"
        }}><span style={{
            fontSize: "1.5vw",
            fontFamily: "'Aptos', sans-serif",
            color: "#4d6073",
            letterSpacing: "-0.01pt"
          }}>{"\u041f\u043e\u043a\u0443\u043f\u0430\u0442\u0435\u043b\u044c \u0432\u0438\u0434\u0438\u0442 \u0442\u043e\u0432\u0430\u0440\u044b \u0442\u043e\u043b\u044c\u043a\u043e \u043f\u043e\u0441\u043b\u0435 \u043f\u0440\u043e\u0432\u0435\u0440\u043a\u0438 \u0430\u0434\u043c\u0438\u043d\u0438\u0441\u0442\u0440\u0430\u0442\u043e\u0440\u043e\u043c."}</span></p></div></div>;
};
export default Slide6;
