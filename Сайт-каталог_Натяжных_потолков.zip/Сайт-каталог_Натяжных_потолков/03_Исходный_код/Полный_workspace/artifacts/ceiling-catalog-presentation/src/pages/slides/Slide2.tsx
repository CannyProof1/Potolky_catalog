import React from "react";
const Slide2: React.FC = () => {
  return <div id="slide-2" className="w-screen h-screen overflow-hidden relative" style={{backgroundColor:"#000"}}><div key={0} style={{
        position: "absolute",
        left: "0vw",
        top: "0vh",
        width: "99.9922vw",
        height: "99.9889vh",
        boxSizing: "border-box",
        backgroundColor: "#f7f9fb",
        boxShadow: "0px 2.42px 4.2px rgba(0, 0, 0, 0.35)"
      }} /><div key={1} style={{
        position: "absolute",
        left: "4.6508vw",
        top: "4.5361vh",
        width: "90.3687vw",
        height: "3.0181vh",
        boxSizing: "border-box",
        backgroundColor: "transparent",
        padding: "0.3986vh 0.2242vw 0.3986vh 0.2242vw",
        wordWrap: "break-word"
      }}><p style={{
          lineHeight: "1.2",
          fontSize: "1.5vw",
          marginTop: "0",
          marginBottom: "0"
        }}><span style={{
            fontSize: "1.5vw",
            fontFamily: "'Aptos', sans-serif",
            fontWeight: "700",
            color: "#1f9f8b",
            letterSpacing: "-0.01pt"
          }}>{"01 \u2022 \u0417\u0410\u0414\u0410\u0427\u0410 \u0418 \u041F\u041E\u041B\u042C\u0417\u041E\u0412\u0410\u0422\u0415\u041B\u0418"}</span></p></div><div key={2} style={{
        position: "absolute",
        left: "4.6508vw",
        top: "9.2028vh",
        width: "90.3687vw",
        height: "7.0181vh",
        boxSizing: "border-box",
        backgroundColor: "transparent",
        padding: "0.3986vh 0.2242vw 0.3986vh 0.2242vw",
        wordWrap: "break-word"
      }}><p style={{
          lineHeight: "1.2",
          fontSize: "2.9167vw",
          marginTop: "0",
          marginBottom: "0"
        }}><span style={{
            fontSize: "2.9167vw",
            fontFamily: "'Aptos', sans-serif",
            fontWeight: "700",
            color: "#14263d",
            letterSpacing: "-0.01pt"
          }}>{"\u041a\u043e\u043c\u0443 \u043d\u0443\u0436\u0435\u043d \u0441\u0430\u0439\u0442-\u043a\u0430\u0442\u0430\u043b\u043e\u0433"}</span></p></div><div key={3} style={{
        position: "absolute",
        left: "4.6508vw",
        top: "18.3986vh",
        width: "90.3687vw",
        height: "0.325vh",
        boxSizing: "border-box",
        backgroundColor: "#dde4eb",
        boxShadow: "0px 2.42px 4.2px rgba(0, 0, 0, 0.35)"
      }} /><div key={4} style={{
        position: "absolute",
        left: "4.6508vw",
        top: "94.9347vh",
        width: "73.4938vw",
        height: "2.8028vh",
        boxSizing: "border-box",
        backgroundColor: "transparent",
        padding: "0.3986vh 0.2242vw 0.3986vh 0.2242vw",
        wordWrap: "break-word"
      }}><p style={{
          lineHeight: "1.2",
          fontSize: "1.5vw",
          marginTop: "0",
          marginBottom: "0"
        }}><span style={{
            fontSize: "1.5vw",
            fontFamily: "'Aptos', sans-serif",
            color: "#617182",
            letterSpacing: "-0.01pt"
          }}>{"\u0414\u0438\u043f\u043b\u043e\u043c\u043d\u044b\u0439 \u043f\u0440\u043e\u0435\u043a\u0442 \u2022 \u041c\u0430\u0442\u0432\u0435\u0439 \u041d\u0430\u043c\u0430\u0437\u043e\u0432 \u2022 \u0421\u0430\u0439\u0442-\u043a\u0430\u0442\u0430\u043b\u043e\u0433 \u043d\u0430\u0442\u044f\u0436\u043d\u044b\u0445 \u043f\u043e\u0442\u043e\u043b\u043a\u043e\u0432"}</span></p></div><div key={5} style={{
        position: "absolute",
        left: "87.9008vw",
        top: "94.6667vh",
        width: "7.1188vw",
        height: "2.7931vh",
        boxSizing: "border-box",
        backgroundColor: "transparent",
        padding: "0.3986vh 0.2242vw 0.3986vh 0.2242vw",
        wordWrap: "break-word"
      }}><p style={{
          textAlign: "right",
          lineHeight: "1.2",
          fontSize: "1.5vw",
          marginTop: "0",
          marginBottom: "0"
        }}><span style={{
            fontSize: "1.5vw",
            fontFamily: "'Aptos', sans-serif",
            color: "#617182",
            letterSpacing: "-0.01pt"
          }}>{"02 / 11"}</span></p></div><div key={6} style={{
        position: "absolute",
        left: "4.6508vw",
        top: "22.3986vh",
        width: "28.8687vw",
        height: "43.3222vh",
        boxSizing: "border-box",
        backgroundColor: "#ffffff",
        border: "1.06px solid #dde4eb",
        borderRadius: "51.99px",
        boxShadow: "0px 2.42px 4.2px rgba(0, 0, 0, 0.35)"
      }} /><div key={7} style={{
        position: "absolute",
        left: "4.7242vw",
        top: "24.7972vh",
        width: "0.4078vw",
        height: "38.525vh",
        boxSizing: "border-box",
        backgroundColor: "#1f9f8b",
        boxShadow: "0px 2.42px 4.2px rgba(0, 0, 0, 0.35)"
      }} /><div key={8} style={{
        position: "absolute",
        left: "6.4484vw",
        top: "24.7972vh",
        width: "25.7188vw",
        height: "4.5778vh",
        boxSizing: "border-box",
        backgroundColor: "transparent",
        padding: "0.3986vh 0.2242vw 0.3986vh 0.2242vw",
        wordWrap: "break-word"
      }}><p style={{
          lineHeight: "1.2",
          fontSize: "1.7708vw",
          marginTop: "0",
          marginBottom: "0"
        }}><span style={{
            fontSize: "1.7708vw",
            fontFamily: "'Aptos', sans-serif",
            fontWeight: "700",
            color: "#14263d",
            letterSpacing: "-0.01pt"
          }}>{"\u041f\u043e\u043a\u0443\u043f\u0430\u0442\u0435\u043b\u044c"}</span></p></div><div key={9} style={{
        position: "absolute",
        left: "6.4484vw",
        top: "30.6667vh",
        width: "25.568vw",
        height: "7.4597vh",
        boxSizing: "border-box",
        backgroundColor: "transparent",
        padding: "0.3986vh 0.2242vw 0.3986vh 0.2242vw",
        wordWrap: "break-word"
      }}><p style={{
          lineHeight: "1.2",
          fontSize: "1.5625vw",
          marginTop: "0",
          marginBottom: "0"
        }}><span style={{
            fontSize: "1.5625vw",
            fontFamily: "'Aptos', sans-serif",
            color: "#243447",
            letterSpacing: "-0.01pt"
          }}>{"\u0421\u043c\u043e\u0442\u0440\u0438\u0442 \u043e\u0434\u043e\u0431\u0440\u0435\u043d\u043d\u044b\u0435 \u0442\u043e\u0432\u0430\u0440\u044b \u0438 \u043e\u0442\u043f\u0440\u0430\u0432\u043b\u044f\u0435\u0442 \u0437\u0430\u044f\u0432\u043a\u0443 \u0431\u0435\u0437 \u043e\u043f\u043b\u0430\u0442\u044b."}</span></p></div><div key={10} style={{
        position: "absolute",
        left: "35.5516vw",
        top: "22.3986vh",
        width: "28.8687vw",
        height: "43.3222vh",
        boxSizing: "border-box",
        backgroundColor: "#ffffff",
        border: "1.06px solid #dde4eb",
        borderRadius: "51.99px",
        boxShadow: "0px 2.42px 4.2px rgba(0, 0, 0, 0.35)"
      }} /><div key={11} style={{
        position: "absolute",
        left: "35.625vw",
        top: "24.7972vh",
        width: "0.4078vw",
        height: "38.525vh",
        boxSizing: "border-box",
        backgroundColor: "#4a84be",
        boxShadow: "0px 2.42px 4.2px rgba(0, 0, 0, 0.35)"
      }} /><div key={12} style={{
        position: "absolute",
        left: "37.3492vw",
        top: "24.7972vh",
        width: "25.7188vw",
        height: "4.5778vh",
        boxSizing: "border-box",
        backgroundColor: "transparent",
        padding: "0.3986vh 0.2242vw 0.3986vh 0.2242vw",
        wordWrap: "break-word"
      }}><p style={{
          lineHeight: "1.2",
          fontSize: "1.7708vw",
          marginTop: "0",
          marginBottom: "0"
        }}><span style={{
            fontSize: "1.7708vw",
            fontFamily: "'Aptos', sans-serif",
            fontWeight: "700",
            color: "#14263d",
            letterSpacing: "-0.01pt"
          }}>{"\u041f\u0440\u043e\u0434\u0430\u0432\u0435\u0446"}</span></p></div><div key={13} style={{
        position: "absolute",
        left: "37.3492vw",
        top: "30.6667vh",
        width: "25.568vw",
        height: "10.7875vh",
        boxSizing: "border-box",
        backgroundColor: "transparent",
        padding: "0.3986vh 0.2242vw 0.3986vh 0.2242vw",
        wordWrap: "break-word"
      }}><p style={{
          lineHeight: "1.2",
          fontSize: "1.5625vw",
          marginTop: "0",
          marginBottom: "0"
        }}><span style={{
            fontSize: "1.5625vw",
            fontFamily: "'Aptos', sans-serif",
            color: "#243447",
            letterSpacing: "-0.01pt"
          }}>{"\u0414\u043e\u0431\u0430\u0432\u043b\u044f\u0435\u0442 \u0438 \u0440\u0435\u0434\u0430\u043a\u0442\u0438\u0440\u0443\u0435\u0442 \u043a\u0430\u0440\u0442\u043e\u0447\u043a\u0438; \u043e\u0442\u043f\u0440\u0430\u0432\u043b\u044f\u0435\u0442 \u0438\u0445 \u043d\u0430 \u043f\u0440\u043e\u0432\u0435\u0440\u043a\u0443."}</span></p></div><div key={14} style={{
        position: "absolute",
        left: "66.4484vw",
        top: "22.3986vh",
        width: "28.8687vw",
        height: "43.3222vh",
        boxSizing: "border-box",
        backgroundColor: "#ffffff",
        border: "1.06px solid #dde4eb",
        borderRadius: "51.99px",
        boxShadow: "0px 2.42px 4.2px rgba(0, 0, 0, 0.35)"
      }} /><div key={15} style={{
        position: "absolute",
        left: "66.5258vw",
        top: "24.7972vh",
        width: "0.4078vw",
        height: "38.525vh",
        boxSizing: "border-box",
        backgroundColor: "#d99137",
        boxShadow: "0px 2.42px 4.2px rgba(0, 0, 0, 0.35)"
      }} /><div key={16} style={{
        position: "absolute",
        left: "68.25vw",
        top: "24.7972vh",
        width: "25.7188vw",
        height: "4.5778vh",
        boxSizing: "border-box",
        backgroundColor: "transparent",
        padding: "0.3986vh 0.2242vw 0.3986vh 0.2242vw",
        wordWrap: "break-word"
      }}><p style={{
          lineHeight: "1.2",
          fontSize: "1.7708vw",
          marginTop: "0",
          marginBottom: "0"
        }}><span style={{
            fontSize: "1.7708vw",
            fontFamily: "'Aptos', sans-serif",
            fontWeight: "700",
            color: "#14263d",
            letterSpacing: "-0.01pt"
          }}>{"\u0410\u0434\u043c\u0438\u043d\u0438\u0441\u0442\u0440\u0430\u0442\u043e\u0440"}</span></p></div><div key={17} style={{
        position: "absolute",
        left: "68.25vw",
        top: "30.6667vh",
        width: "25.568vw",
        height: "10.7875vh",
        boxSizing: "border-box",
        backgroundColor: "transparent",
        padding: "0.3986vh 0.2242vw 0.3986vh 0.2242vw",
        wordWrap: "break-word"
      }}><p style={{
          lineHeight: "1.2",
          fontSize: "1.5625vw",
          marginTop: "0",
          marginBottom: "0"
        }}><span style={{
            fontSize: "1.5625vw",
            fontFamily: "'Aptos', sans-serif",
            color: "#243447",
            letterSpacing: "-0.01pt"
          }}>{"\u041f\u0440\u043e\u0432\u0435\u0440\u044f\u0435\u0442 \u0442\u043e\u0432\u0430\u0440\u044b, \u0437\u0430\u044f\u0432\u043a\u0438, \u043f\u043e\u043b\u044c\u0437\u043e\u0432\u0430\u0442\u0435\u043b\u0435\u0439 \u0438 \u043e\u0431\u0440\u0430\u0449\u0435\u043d\u0438\u044f \u043f\u043e\u0434\u0434\u0435\u0440\u0436\u043a\u0438."}</span></p></div><div key={18} style={{
        position: "absolute",
        left: "4.6508vw",
        top: "70.9347vh",
        width: "90.6703vw",
        height: "12.2569vh",
        boxSizing: "border-box",
        backgroundColor: "#e1f4f0",
        border: "1.06px solid #e1f4f0",
        borderRadius: "14.71px",
        boxShadow: "0px 2.42px 4.2px rgba(0, 0, 0, 0.35)"
      }} /><div key={19} style={{
        position: "absolute",
        left: "6.75vw",
        top: "74.5361vh",
        width: "86.6188vw",
        height: "4.1306vh",
        boxSizing: "border-box",
        backgroundColor: "transparent",
        padding: "0.3986vh 0.2242vw 0.3986vh 0.2242vw",
        wordWrap: "break-word"
      }}><p style={{
          textAlign: "center",
          lineHeight: "1.2",
          fontSize: "1.5625vw",
          marginTop: "0",
          marginBottom: "0"
        }}><span style={{
            fontSize: "1.5625vw",
            fontFamily: "'Aptos', sans-serif",
            fontWeight: "700",
            color: "#176f63",
            letterSpacing: "-0.01pt"
          }}>{"\u041f\u0420\u041e\u0414\u0410\u0412\u0415\u0426 \u0414\u041e\u0411\u0410\u0412\u041b\u042f\u0415\u0422 \u2192 \u0410\u0414\u041c\u0418\u041d \u041f\u0420\u041e\u0412\u0415\u0420\u042f\u0415\u0422 \u2192 \u0422\u041e\u0412\u0410\u0420 \u0412 \u041a\u0410\u0422\u0410\u041b\u041e\u0413\u0415 \u2192 \u0417\u0410\u042f\u0412\u041a\u0410 \u041f\u041e\u041a\u0423\u041f\u0410\u0422\u0415\u041b\u042f"}</span></p></div></div>;
};
export default Slide2;
