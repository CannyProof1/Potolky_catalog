import type { CatalogProduct } from "@workspace/api-zod";

/**
 * Add only real, owner-approved products here.
 * The catalog intentionally starts empty because no product details were supplied.
 */
export const catalogProducts: CatalogProduct[] = [];
