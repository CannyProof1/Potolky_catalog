import {
  CreateSupportTicketBody,
  CreateSupportTicketResponse,
  GetSupportTicketParams,
  GetSupportTicketResponse,
  ListAdminSupportTicketsResponse,
  ListMySupportTicketsResponse,
  ReplySupportTicketBody,
  ReplySupportTicketParams,
  ReplySupportTicketResponse,
  UpdateAdminSupportTicketBody,
  UpdateAdminSupportTicketParams,
  UpdateAdminSupportTicketResponse,
} from "@workspace/api-zod";
import {
  appUsersTable,
  db,
  supportMessagesTable,
  supportTicketsTable,
  type AppUser,
} from "@workspace/db";
import { asc, desc, eq } from "drizzle-orm";
import { Router, type IRouter } from "express";
import { requireAdmin, requireAppUser, requireAuth } from "../middlewares/auth";

const router: IRouter = Router();

function ticketSummary(
  ticket: typeof supportTicketsTable.$inferSelect,
  user: AppUser,
) {
  return {
    id: ticket.id,
    userId: ticket.userId,
    requesterDisplayName: user.displayName,
    requesterEmail: user.email,
    subject: ticket.subject,
    status: ticket.status,
    createdAt: ticket.createdAt,
    updatedAt: ticket.updatedAt,
  };
}

async function getTicketDetail(ticketId: string) {
  const [row] = await db
    .select({ ticket: supportTicketsTable, user: appUsersTable })
    .from(supportTicketsTable)
    .innerJoin(
      appUsersTable,
      eq(supportTicketsTable.userId, appUsersTable.clerkUserId),
    )
    .where(eq(supportTicketsTable.id, ticketId))
    .limit(1);
  if (!row) return null;

  const messages = await db
    .select({ message: supportMessagesTable, sender: appUsersTable })
    .from(supportMessagesTable)
    .innerJoin(
      appUsersTable,
      eq(supportMessagesTable.senderId, appUsersTable.clerkUserId),
    )
    .where(eq(supportMessagesTable.ticketId, ticketId))
    .orderBy(asc(supportMessagesTable.createdAt));

  return {
    ...ticketSummary(row.ticket, row.user),
    messages: messages.map(({ message, sender }) => ({
      id: message.id,
      senderUserId: sender.clerkUserId,
      senderDisplayName: sender.displayName,
      senderRole: sender.role,
      body: message.body,
      createdAt: message.createdAt,
    })),
  };
}

router.get(
  "/support/tickets",
  requireAuth,
  requireAppUser,
  async (_req, res): Promise<void> => {
    const user = res.locals.appUser as AppUser;
    const rows = await db
      .select({ ticket: supportTicketsTable, user: appUsersTable })
      .from(supportTicketsTable)
      .innerJoin(
        appUsersTable,
        eq(supportTicketsTable.userId, appUsersTable.clerkUserId),
      )
      .where(eq(supportTicketsTable.userId, user.clerkUserId))
      .orderBy(desc(supportTicketsTable.updatedAt));
    res.setHeader("Cache-Control", "no-store");
    res.json(
      ListMySupportTicketsResponse.parse({
        tickets: rows.map(({ ticket, user: requester }) =>
          ticketSummary(ticket, requester),
        ),
      }),
    );
  },
);

router.post(
  "/support/tickets",
  requireAuth,
  requireAppUser,
  async (req, res): Promise<void> => {
    const parsed = CreateSupportTicketBody.safeParse(req.body);
    if (!parsed.success) {
      res.status(400).json({ error: "Укажите тему и текст обращения." });
      return;
    }
    const user = res.locals.appUser as AppUser;
    const created = await db.transaction(async (tx) => {
      const [ticket] = await tx
        .insert(supportTicketsTable)
        .values({
          userId: user.clerkUserId,
          subject: parsed.data.subject.trim(),
        })
        .returning();
      await tx.insert(supportMessagesTable).values({
        ticketId: ticket.id,
        senderId: user.clerkUserId,
        body: parsed.data.body.trim(),
      });
      return ticket;
    });
    const detail = await getTicketDetail(created.id);
    if (!detail) {
      res.status(500).json({ error: "Не удалось открыть обращение." });
      return;
    }
    res.status(201).json(CreateSupportTicketResponse.parse(detail));
  },
);

router.get(
  "/support/tickets/:ticketId",
  requireAuth,
  requireAppUser,
  async (req, res): Promise<void> => {
    const parsedParams = GetSupportTicketParams.safeParse(req.params);
    if (!parsedParams.success) {
      res.status(404).json({ error: "Обращение не найдено." });
      return;
    }
    const user = res.locals.appUser as AppUser;
    const detail = await getTicketDetail(parsedParams.data.ticketId);
    if (
      !detail ||
      (detail.userId !== user.clerkUserId && user.role !== "admin")
    ) {
      res.status(404).json({ error: "Обращение не найдено." });
      return;
    }
    res.setHeader("Cache-Control", "no-store");
    res.json(GetSupportTicketResponse.parse(detail));
  },
);

router.post(
  "/support/tickets/:ticketId/messages",
  requireAuth,
  requireAppUser,
  async (req, res): Promise<void> => {
    const parsedParams = ReplySupportTicketParams.safeParse(req.params);
    const parsedBody = ReplySupportTicketBody.safeParse(req.body);
    if (!parsedParams.success || !parsedBody.success) {
      res.status(400).json({ error: "Введите сообщение для поддержки." });
      return;
    }
    const user = res.locals.appUser as AppUser;
    const [ticket] = await db
      .select()
      .from(supportTicketsTable)
      .where(eq(supportTicketsTable.id, parsedParams.data.ticketId))
      .limit(1);
    if (
      !ticket ||
      (ticket.userId !== user.clerkUserId && user.role !== "admin")
    ) {
      res.status(404).json({ error: "Обращение не найдено." });
      return;
    }

    await db.transaction(async (tx) => {
      await tx.insert(supportMessagesTable).values({
        ticketId: ticket.id,
        senderId: user.clerkUserId,
        body: parsedBody.data.body.trim(),
      });
      await tx
        .update(supportTicketsTable)
        .set({
          status: user.role === "admin" ? "answered" : "open",
          updatedAt: new Date(),
        })
        .where(eq(supportTicketsTable.id, ticket.id));
    });

    const detail = await getTicketDetail(ticket.id);
    if (!detail) {
      res.status(500).json({ error: "Не удалось обновить обращение." });
      return;
    }
    res.status(201).json(ReplySupportTicketResponse.parse(detail));
  },
);

router.get(
  "/admin/support/tickets",
  requireAuth,
  requireAppUser,
  requireAdmin,
  async (_req, res): Promise<void> => {
    const rows = await db
      .select({ ticket: supportTicketsTable, user: appUsersTable })
      .from(supportTicketsTable)
      .innerJoin(
        appUsersTable,
        eq(supportTicketsTable.userId, appUsersTable.clerkUserId),
      )
      .orderBy(desc(supportTicketsTable.updatedAt));
    res.setHeader("Cache-Control", "no-store");
    res.json(
      ListAdminSupportTicketsResponse.parse({
        tickets: rows.map(({ ticket, user }) => ticketSummary(ticket, user)),
      }),
    );
  },
);

router.patch(
  "/admin/support/tickets/:ticketId",
  requireAuth,
  requireAppUser,
  requireAdmin,
  async (req, res): Promise<void> => {
    const parsedParams = UpdateAdminSupportTicketParams.safeParse(req.params);
    const parsedBody = UpdateAdminSupportTicketBody.safeParse(req.body);
    if (!parsedParams.success || !parsedBody.success) {
      res.status(400).json({ error: "Проверьте статус обращения." });
      return;
    }
    const [ticket] = await db
      .update(supportTicketsTable)
      .set({
        status: parsedBody.data.status,
        updatedAt: new Date(),
      })
      .where(eq(supportTicketsTable.id, parsedParams.data.ticketId))
      .returning({ id: supportTicketsTable.id });
    if (!ticket) {
      res.status(404).json({ error: "Обращение не найдено." });
      return;
    }
    const detail = await getTicketDetail(ticket.id);
    if (!detail) {
      res.status(404).json({ error: "Обращение не найдено." });
      return;
    }
    res.json(UpdateAdminSupportTicketResponse.parse(detail));
  },
);

export default router;
