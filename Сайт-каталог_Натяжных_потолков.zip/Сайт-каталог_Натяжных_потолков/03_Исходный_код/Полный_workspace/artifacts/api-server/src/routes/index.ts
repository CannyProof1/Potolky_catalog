import { Router, type IRouter } from "express";
import healthRouter from "./health";
import catalogRouter from "./catalog";
import usersRouter from "./users";
import sellerProductsRouter from "./sellerProducts";
import adminRouter from "./admin";
import supportRouter from "./support";

const router: IRouter = Router();

router.use(healthRouter);
router.use(catalogRouter);
router.use(usersRouter);
router.use(sellerProductsRouter);
router.use(adminRouter);
router.use(supportRouter);

export default router;
