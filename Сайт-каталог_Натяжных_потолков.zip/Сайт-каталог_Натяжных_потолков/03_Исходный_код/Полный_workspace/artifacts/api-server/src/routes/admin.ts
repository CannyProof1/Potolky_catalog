import {
  GetAdminDashboardResponse,
  ListAdminOrderRequestsResponse,
  ListAdminUsersResponse,
  UpdateAdminOrderRequestBody,
  UpdateAdminOrderRequestParams,
  UpdateAdminOrderRequestResponse,
  UpdateAdminUserBody,
  UpdateAdminUserParams,
  UpdateAdminUserResponse,
} from "@workspace/api-zod";
import {
  appUsersTable,
  db,
  orderRequestsTable,
  sellerProductsTable,
  supportTicketsTable,
  type AppUser,
} from "@workspace/db";
import { and, count, desc, eq, ne } from "drizzle-orm";
import { Router, type IRouter } from "express";
import { requireAdmin, requireAppUser, requireAuth } from "../middlewares/auth";

const router: IRouter = Router();

function userResponse(user: AppUser) {
  return {
    clerkUserId: user.clerkUserId,
    email: user.email,
    displayName: user.displayName,
    username: user.username,
    role: user.role,
    isBlocked: user.isBlocked,
    createdAt: user.createdAt,
  };
}

router.get(
  "/admin/dashboard",
  requireAuth,
  requireAppUser,
  requireAdmin,
  async (_req, res): Promise<void> => {
    const [users, sellers, pendingProducts, products, newRequests, openTickets] =
      await Promise.all([
        db.select({ value: count() }).from(appUsersTable),
        db
          .select({ value: count() })
          .from(appUsersTable)
          .where(eq(appUsersTable.role, "seller")),
        db
          .select({ value: count() })
          .from(sellerProductsTable)
          .where(eq(sellerProductsTable.status, "pending")),
        db.select({ value: count() }).from(sellerProductsTable),
        db
          .select({ value: count() })
          .from(orderRequestsTable)
          .where(eq(orderRequestsTable.status, "new")),
        db
          .select({ value: count() })
          .from(supportTicketsTable)
          .where(eq(supportTicketsTable.status, "open")),
      ]);
    res.json(
      GetAdminDashboardResponse.parse({
        usersCount: Number(users[0]?.value ?? 0),
        sellersCount: Number(sellers[0]?.value ?? 0),
        pendingProductsCount: Number(pendingProducts[0]?.value ?? 0),
        productsCount: Number(products[0]?.value ?? 0),
        newRequestsCount: Number(newRequests[0]?.value ?? 0),
        openSupportTicketsCount: Number(openTickets[0]?.value ?? 0),
      }),
    );
  },
);

router.get(
  "/admin/users",
  requireAuth,
  requireAppUser,
  requireAdmin,
  async (_req, res): Promise<void> => {
    const users = await db
      .select()
      .from(appUsersTable)
      .orderBy(desc(appUsersTable.createdAt));
    res.setHeader("Cache-Control", "no-store");
    res.json(
      ListAdminUsersResponse.parse({
        users: users.map(userResponse),
      }),
    );
  },
);

router.patch(
  "/admin/users/:userId",
  requireAuth,
  requireAppUser,
  requireAdmin,
  async (req, res): Promise<void> => {
    const parsedParams = UpdateAdminUserParams.safeParse(req.params);
    const parsedBody = UpdateAdminUserBody.safeParse(req.body);
    if (!parsedParams.success || !parsedBody.success) {
      res.status(400).json({ error: "Проверьте роль и статус аккаунта." });
      return;
    }
    const actor = res.locals.appUser as AppUser;
    const targetId = parsedParams.data.userId;
    const input = parsedBody.data;
    if (
      targetId === actor.clerkUserId &&
      (input.role !== actor.role || input.isBlocked)
    ) {
      res.status(400).json({
        error: "Нельзя изменить собственную роль или заблокировать себя.",
      });
      return;
    }

    const [target] = await db
      .select()
      .from(appUsersTable)
      .where(eq(appUsersTable.clerkUserId, targetId))
      .limit(1);
    if (!target) {
      res.status(404).json({ error: "Пользователь не найден." });
      return;
    }

    if (target.role === "admin" && input.role !== "admin") {
      const [activeAdmins] = await db
        .select({ value: count() })
        .from(appUsersTable)
        .where(
          and(
            eq(appUsersTable.role, "admin"),
            eq(appUsersTable.isBlocked, false),
            ne(appUsersTable.clerkUserId, targetId),
          ),
        );
      if (Number(activeAdmins?.value ?? 0) === 0) {
        res.status(409).json({
          error: "Нельзя снять права с последнего активного администратора.",
        });
        return;
      }
    }

    const [updated] = await db
      .update(appUsersTable)
      .set({ role: input.role, isBlocked: input.isBlocked, updatedAt: new Date() })
      .where(eq(appUsersTable.clerkUserId, targetId))
      .returning();
    res.json(UpdateAdminUserResponse.parse(userResponse(updated)));
  },
);

router.get(
  "/admin/order-requests",
  requireAuth,
  requireAppUser,
  requireAdmin,
  async (_req, res): Promise<void> => {
    const requests = await db
      .select()
      .from(orderRequestsTable)
      .orderBy(desc(orderRequestsTable.createdAt));
    res.setHeader("Cache-Control", "no-store");
    res.json(
      ListAdminOrderRequestsResponse.parse({
        requests: requests.map((request) => ({
          id: request.id,
          customerName: request.customerName,
          customerContact: request.customerContact,
          message: request.message,
          items: request.items,
          status: request.status,
          privacyConsentAt: request.privacyConsentAt,
          createdAt: request.createdAt,
        })),
      }),
    );
  },
);

router.patch(
  "/admin/order-requests/:requestId",
  requireAuth,
  requireAppUser,
  requireAdmin,
  async (req, res): Promise<void> => {
    const parsedParams = UpdateAdminOrderRequestParams.safeParse(req.params);
    const parsedBody = UpdateAdminOrderRequestBody.safeParse(req.body);
    if (!parsedParams.success || !parsedBody.success) {
      res.status(400).json({ error: "Проверьте статус заявки." });
      return;
    }
    const [updated] = await db
      .update(orderRequestsTable)
      .set({ status: parsedBody.data.status })
      .where(eq(orderRequestsTable.id, parsedParams.data.requestId))
      .returning();
    if (!updated) {
      res.status(404).json({ error: "Заявка не найдена." });
      return;
    }
    res.json(
      UpdateAdminOrderRequestResponse.parse({
        id: updated.id,
        customerName: updated.customerName,
        customerContact: updated.customerContact,
        message: updated.message,
        items: updated.items,
        status: updated.status,
        privacyConsentAt: updated.privacyConsentAt,
        createdAt: updated.createdAt,
      }),
    );
  },
);

export default router;
