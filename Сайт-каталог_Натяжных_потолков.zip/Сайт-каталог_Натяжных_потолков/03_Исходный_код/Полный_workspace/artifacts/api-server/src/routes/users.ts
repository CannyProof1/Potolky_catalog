import {
  GetCurrentUserResponse,
  SyncCurrentUserBody,
  SyncCurrentUserResponse,
} from "@workspace/api-zod";
import { appUsersTable } from "@workspace/db";
import { Router, type IRouter } from "express";
import {
  getRequestUserId,
  ProfileSyncError,
  requireAppUser,
  requireAuth,
  syncCurrentAppUser,
} from "../middlewares/auth";

const router: IRouter = Router();

function profileResponse(user: typeof appUsersTable.$inferSelect) {
  return {
    clerkUserId: user.clerkUserId,
    email: user.email,
    displayName: user.displayName,
    username: user.username,
    role: user.role,
    isBlocked: user.isBlocked,
    createdAt: user.createdAt,
  };
}

router.get(
  "/users/me",
  requireAppUser,
  (_req, res): void => {
    const user = res.locals.appUser as typeof appUsersTable.$inferSelect;
    res.setHeader("Cache-Control", "no-store");
    res.json(GetCurrentUserResponse.parse(profileResponse(user)));
  },
);

router.post(
  "/users/me",
  requireAuth,
  async (req, res): Promise<void> => {
    const parsedBody = SyncCurrentUserBody.safeParse(req.body);
    if (!parsedBody.success) {
      res.status(400).json({ error: "Выберите допустимый тип аккаунта." });
      return;
    }

    const userId = getRequestUserId(req);
    if (!userId) {
      res.status(401).json({ error: "Войдите в аккаунт, чтобы продолжить." });
      return;
    }

    try {
      const user = await syncCurrentAppUser(
        userId,
        parsedBody.data.registrationRole,
      );
      if (user.isBlocked) {
        res.status(403).json({ error: "Доступ к аккаунту ограничен." });
        return;
      }
      res.setHeader("Cache-Control", "no-store");
      res.json(SyncCurrentUserResponse.parse(profileResponse(user)));
    } catch (error) {
      if (error instanceof ProfileSyncError) {
        res.status(error.statusCode).json({ error: error.message });
        return;
      }
      req.log.error(
        { errorType: error instanceof Error ? error.name : "UnknownError" },
        "Could not synchronize account profile",
      );
      res.status(500).json({ error: "Не удалось загрузить профиль." });
    }
  },
);

export default router;
