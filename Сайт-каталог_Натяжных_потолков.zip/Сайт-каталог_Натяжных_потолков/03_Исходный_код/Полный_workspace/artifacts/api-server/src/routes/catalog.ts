import {
  CreateOrderRequestBody,
  CreateOrderRequestResponse,
  GetCatalogProductParams,
  GetCatalogProductResponse,
  ListCatalogProductsResponse,
  type CatalogProduct,
} from "@workspace/api-zod";
import {
  appUsersTable,
  db,
  orderRequestsTable,
  sellerProductsTable,
  type OrderRequestItemSnapshot,
} from "@workspace/db";
import { desc, eq } from "drizzle-orm";
import { Router, type IRouter } from "express";

const router: IRouter = Router();

function toCatalogProduct(
  product: typeof sellerProductsTable.$inferSelect,
  vendor: string,
): CatalogProduct {
  const image = product.imageUrl
    ? { url: product.imageUrl, altText: product.title }
    : null;
  const price = { amount: product.price, currencyCode: "RUB" };

  return {
    id: product.id,
    handle: product.handle,
    title: product.title,
    description: product.description,
    vendor,
    productType: product.category,
    availableForSale: product.status === "approved",
    featuredImage: image,
    images: image ? [image] : [],
    price,
    variants: [
      {
        id: product.id,
        title: "Стандартный вариант",
        availableForSale: product.status === "approved",
        price,
        selectedOptions: [],
      },
    ],
    tags: [product.category, product.material].filter(Boolean),
    specifications: {
      category: product.category,
      material: product.material,
      texture: product.texture,
      color: product.color,
      size: product.size,
    },
  };
}

router.get("/catalog/products", async (_req, res): Promise<void> => {
  const rows = await db
    .select({
      product: sellerProductsTable,
      seller: { displayName: appUsersTable.displayName },
    })
    .from(sellerProductsTable)
    .innerJoin(
      appUsersTable,
      eq(sellerProductsTable.sellerId, appUsersTable.clerkUserId),
    )
    .where(eq(sellerProductsTable.status, "approved"))
    .orderBy(desc(sellerProductsTable.createdAt));
  const products = rows.map(({ product, seller }) =>
    toCatalogProduct(product, seller.displayName),
  );
  res.setHeader("Cache-Control", "no-store");
  res.json(ListCatalogProductsResponse.parse({ products }));
});

router.get("/catalog/products/:handle", async (req, res): Promise<void> => {
  const parsedParams = GetCatalogProductParams.safeParse(req.params);
  if (!parsedParams.success) {
    res.status(400).json({ error: "Некорректная ссылка на товар." });
    return;
  }

  const [row] = await db
    .select({
      product: sellerProductsTable,
      seller: { displayName: appUsersTable.displayName },
    })
    .from(sellerProductsTable)
    .innerJoin(
      appUsersTable,
      eq(sellerProductsTable.sellerId, appUsersTable.clerkUserId),
    )
    .where(
      eq(sellerProductsTable.handle, parsedParams.data.handle),
    )
    .limit(1);
  if (!row || row.product.status !== "approved") {
    res.status(404).json({ error: "Товар не найден в каталоге." });
    return;
  }

  res.setHeader("Cache-Control", "no-store");
  res.json(
    GetCatalogProductResponse.parse(
      toCatalogProduct(row.product, row.seller.displayName),
    ),
  );
});

function isEmailOrPhone(contact: string) {
  const email = /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(contact);
  const digits = contact.replace(/\D/g, "");
  const phone =
    digits.length >= 7 &&
    digits.length <= 15 &&
    /^[+\d().\-\s]+$/.test(contact);
  return email || phone;
}

router.post("/order-requests", async (req, res): Promise<void> => {
  const parsedBody = CreateOrderRequestBody.safeParse(req.body);
  if (!parsedBody.success) {
    res.status(400).json({
      error: "Проверьте контактные данные и состав заявки.",
    });
    return;
  }

  const input = parsedBody.data;
  const customerName = input.name.trim();
  const customerContact = input.contact.trim();
  if (!customerName || !isEmailOrPhone(customerContact)) {
    res.status(400).json({
      error: "Укажите имя и корректный телефон или адрес электронной почты.",
    });
    return;
  }
  if (input.privacyConsent !== true) {
    res.status(400).json({
      error: "Для отправки заявки необходимо согласие на обработку контакта.",
    });
    return;
  }

  const combinedLines = new Map<
    string,
    { productHandle: string; variantId: string; quantity: number }
  >();
  for (const line of input.lines) {
    const key = `${line.productHandle}\u0000${line.variantId}`;
    const current = combinedLines.get(key);
    const quantity = (current?.quantity ?? 0) + line.quantity;
    if (quantity > 50) {
      res.status(400).json({ error: "Максимум 50 единиц одного варианта." });
      return;
    }
    combinedLines.set(key, { ...line, quantity });
  }

  const snapshots: OrderRequestItemSnapshot[] = [];
  for (const line of combinedLines.values()) {
    const [product] = await db
      .select()
      .from(sellerProductsTable)
      .where(
        eq(sellerProductsTable.handle, line.productHandle),
      )
      .limit(1);
    if (
      !product ||
      product.status !== "approved" ||
      product.id !== line.variantId
    ) {
      res.status(409).json({
        error: "Один из товаров больше недоступен. Обновите каталог и попробуйте снова.",
      });
      return;
    }

    snapshots.push({
      productHandle: product.handle,
      productTitle: product.title,
      variantId: product.id,
      variantTitle: "Стандартный вариант",
      quantity: line.quantity,
      unitPrice: product.price,
      currencyCode: "RUB",
    });
  }

  try {
    const [savedRequest] = await db
      .insert(orderRequestsTable)
      .values({
        customerName,
        customerContact,
        message: input.message?.trim() || null,
        items: snapshots,
      })
      .returning({ id: orderRequestsTable.id });

    res.status(201).json(
      CreateOrderRequestResponse.parse({ requestNumber: savedRequest.id }),
    );
  } catch (error) {
    req.log.error(
      { errorType: error instanceof Error ? error.name : "UnknownError" },
      "Could not save order request",
    );
    res.status(500).json({
      error: "Не удалось сохранить заявку. Попробуйте позже.",
    });
  }
});

export default router;
