import { randomUUID } from "node:crypto";
import {
  CreateSellerProductBody,
  CreateSellerProductResponse,
  ListAdminProductsResponse,
  ListSellerProductsResponse,
  ReviewAdminProductBody,
  ReviewAdminProductParams,
  ReviewAdminProductResponse,
  UpdateSellerProductBody,
  UpdateSellerProductParams,
  UpdateSellerProductResponse,
  type SellerProduct as SellerProductDto,
} from "@workspace/api-zod";
import {
  appUsersTable,
  db,
  sellerProductsTable,
  type AppUser,
} from "@workspace/db";
import { desc, eq } from "drizzle-orm";
import { Router, type IRouter } from "express";
import { requireAdmin, requireAppUser, requireAuth, requireSeller } from "../middlewares/auth";

const router: IRouter = Router();

function slugify(value: string) {
  return (
    value
      .normalize("NFKD")
      .toLowerCase()
      .replace(/[^\p{L}\p{N}]+/gu, "-")
      .replace(/^-|-$/g, "")
      .slice(0, 160) || "tovar"
  );
}

function productResponse(
  product: typeof sellerProductsTable.$inferSelect,
  seller: Pick<AppUser, "clerkUserId" | "displayName" | "email">,
): SellerProductDto {
  return {
    id: product.id,
    sellerId: seller.clerkUserId,
    sellerName: seller.displayName,
    sellerEmail: seller.email,
    title: product.title,
    description: product.description,
    price: product.price,
    specifications: {
      category: product.category,
      material: product.material,
      texture: product.texture,
      color: product.color,
      size: product.size,
    },
    imageUrl: product.imageUrl,
    status: product.status as SellerProductDto["status"],
    adminNote: product.adminNote,
    createdAt: product.createdAt,
    updatedAt: product.updatedAt,
  };
}

async function joinedProduct(productId: string) {
  const [row] = await db
    .select({ product: sellerProductsTable, seller: appUsersTable })
    .from(sellerProductsTable)
    .innerJoin(
      appUsersTable,
      eq(sellerProductsTable.sellerId, appUsersTable.clerkUserId),
    )
    .where(eq(sellerProductsTable.id, productId))
    .limit(1);
  return row;
}

router.get(
  "/seller/products",
  requireAuth,
  requireAppUser,
  requireSeller,
  async (_req, res): Promise<void> => {
    const seller = res.locals.appUser as AppUser;
    const rows = await db
      .select({ product: sellerProductsTable, seller: appUsersTable })
      .from(sellerProductsTable)
      .innerJoin(
        appUsersTable,
        eq(sellerProductsTable.sellerId, appUsersTable.clerkUserId),
      )
      .where(eq(sellerProductsTable.sellerId, seller.clerkUserId))
      .orderBy(desc(sellerProductsTable.createdAt));
    res.setHeader("Cache-Control", "no-store");
    res.json(
      ListSellerProductsResponse.parse({
        products: rows.map(({ product, seller: owner }) =>
          productResponse(product, owner),
        ),
      }),
    );
  },
);

router.post(
  "/seller/products",
  requireAuth,
  requireAppUser,
  requireSeller,
  async (req, res): Promise<void> => {
    const parsed = CreateSellerProductBody.safeParse(req.body);
    if (!parsed.success) {
      res.status(400).json({ error: "Проверьте поля карточки товара." });
      return;
    }
    const seller = res.locals.appUser as AppUser;
    const input = parsed.data;
    const [product] = await db
      .insert(sellerProductsTable)
      .values({
        handle: `${slugify(input.title)}-${randomUUID().slice(0, 8)}`,
        sellerId: seller.clerkUserId,
        title: input.title.trim(),
        description: input.description.trim(),
        price: input.price.toFixed(2),
        category: input.specifications.category.trim(),
        material: input.specifications.material.trim(),
        texture: input.specifications.texture.trim(),
        color: input.specifications.color.trim(),
        size: input.specifications.size.trim(),
        imageUrl: input.imageUrl,
      })
      .returning();
    res.status(201).json(
      CreateSellerProductResponse.parse(productResponse(product, seller)),
    );
  },
);

router.patch(
  "/seller/products/:productId",
  requireAuth,
  requireAppUser,
  requireSeller,
  async (req, res): Promise<void> => {
    const parsedParams = UpdateSellerProductParams.safeParse(req.params);
    const parsedBody = UpdateSellerProductBody.safeParse(req.body);
    if (!parsedParams.success || !parsedBody.success) {
      res.status(400).json({ error: "Проверьте поля карточки товара." });
      return;
    }
    const seller = res.locals.appUser as AppUser;
    const [existing] = await db
      .select()
      .from(sellerProductsTable)
      .where(eq(sellerProductsTable.id, parsedParams.data.productId))
      .limit(1);
    if (!existing || existing.sellerId !== seller.clerkUserId) {
      res.status(404).json({ error: "Товар не найден." });
      return;
    }

    const input = parsedBody.data;
    const [updated] = await db
      .update(sellerProductsTable)
      .set({
        title: input.title.trim(),
        description: input.description.trim(),
        price: input.price.toFixed(2),
        category: input.specifications.category.trim(),
        material: input.specifications.material.trim(),
        texture: input.specifications.texture.trim(),
        color: input.specifications.color.trim(),
        size: input.specifications.size.trim(),
        imageUrl: input.imageUrl,
        status: "pending",
        adminNote: null,
        updatedAt: new Date(),
      })
      .where(eq(sellerProductsTable.id, existing.id))
      .returning();
    res.json(
      UpdateSellerProductResponse.parse(productResponse(updated, seller)),
    );
  },
);

router.get(
  "/admin/products",
  requireAuth,
  requireAppUser,
  requireAdmin,
  async (_req, res): Promise<void> => {
    const rows = await db
      .select({ product: sellerProductsTable, seller: appUsersTable })
      .from(sellerProductsTable)
      .innerJoin(
        appUsersTable,
        eq(sellerProductsTable.sellerId, appUsersTable.clerkUserId),
      )
      .orderBy(desc(sellerProductsTable.createdAt));
    res.setHeader("Cache-Control", "no-store");
    res.json(
      ListAdminProductsResponse.parse({
        products: rows.map(({ product, seller }) =>
          productResponse(product, seller),
        ),
      }),
    );
  },
);

router.patch(
  "/admin/products/:productId",
  requireAuth,
  requireAppUser,
  requireAdmin,
  async (req, res): Promise<void> => {
    const parsedParams = ReviewAdminProductParams.safeParse(req.params);
    const parsedBody = ReviewAdminProductBody.safeParse(req.body);
    if (!parsedParams.success || !parsedBody.success) {
      res.status(400).json({ error: "Проверьте решение по товару." });
      return;
    }
    const [updated] = await db
      .update(sellerProductsTable)
      .set({
        status: parsedBody.data.status,
        adminNote: parsedBody.data.adminNote.trim() || null,
        updatedAt: new Date(),
      })
      .where(eq(sellerProductsTable.id, parsedParams.data.productId))
      .returning();
    if (!updated) {
      res.status(404).json({ error: "Товар не найден." });
      return;
    }

    const joined = await joinedProduct(updated.id);
    if (!joined) {
      res.status(404).json({ error: "Товар не найден." });
      return;
    }
    res.json(
      ReviewAdminProductResponse.parse(
        productResponse(joined.product, joined.seller),
      ),
    );
  },
);

export default router;
