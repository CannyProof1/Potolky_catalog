import { clerkClient, getAuth } from "@clerk/express";
import type { NextFunction, Request, RequestHandler, Response } from "express";
import { eq } from "drizzle-orm";
import {
  adminBootstrapTable,
  appUsersTable,
  db,
  type AppUser,
} from "@workspace/db";

export type AppRole = "customer" | "seller" | "admin";

export class ProfileSyncError extends Error {
  constructor(
    message: string,
    readonly statusCode: number,
  ) {
    super(message);
  }
}

function clerkIdentityError(message: string, statusCode: number) {
  return new ProfileSyncError(message, statusCode);
}

export async function syncCurrentAppUser(
  userId: string,
  registrationRole: "customer" | "seller",
): Promise<AppUser> {
  const clerkUser = await clerkClient.users.getUser(userId);
  const primaryEmail =
    clerkUser.emailAddresses.find(
      (address) => address.id === clerkUser.primaryEmailAddressId,
    ) ?? clerkUser.emailAddresses[0];
  const email = primaryEmail?.emailAddress.trim().toLowerCase();
  const emailIsVerified = primaryEmail?.verification?.status === "verified";

  if (!email || !emailIsVerified) {
    throw clerkIdentityError(
      "Подтвердите адрес электронной почты перед продолжением.",
      400,
    );
  }

  const displayName =
    clerkUser.fullName?.trim() ||
    clerkUser.username?.trim() ||
    email.split("@")[0] ||
    "Пользователь";
  const username = clerkUser.username?.trim() || null;
  const initialAdminEmail = process.env.INITIAL_ADMIN_EMAIL
    ?.trim()
    .toLowerCase();
  const shouldClaimInitialAdmin = email === initialAdminEmail;

  return db.transaction(async (tx) => {
    await tx.insert(adminBootstrapTable).values({ id: 1 }).onConflictDoNothing();
    const [bootstrap] = await tx
      .select()
      .from(adminBootstrapTable)
      .where(eq(adminBootstrapTable.id, 1))
      .for("update");

    const [existing] = await tx
      .select()
      .from(appUsersTable)
      .where(eq(appUsersTable.clerkUserId, userId))
      .limit(1);

    const mayClaimAdmin =
      shouldClaimInitialAdmin && !bootstrap?.claimedUserId;
    const role: AppRole = mayClaimAdmin
      ? "admin"
      : (existing?.role as AppRole | undefined) ?? registrationRole;

    let user: AppUser;
    if (existing) {
      const [updated] = await tx
        .update(appUsersTable)
        .set({ email, displayName, username, role })
        .where(eq(appUsersTable.clerkUserId, userId))
        .returning();
      user = updated;
    } else {
      const [created] = await tx
        .insert(appUsersTable)
        .values({
          clerkUserId: userId,
          email,
          displayName,
          username,
          role,
        })
        .returning();
      user = created;
    }

    if (mayClaimAdmin) {
      await tx
        .update(adminBootstrapTable)
        .set({ claimedUserId: userId, claimedAt: new Date() })
        .where(eq(adminBootstrapTable.id, 1));
    }

    return user;
  });
}

export function getRequestUserId(req: Request): string | null {
  return getAuth(req).userId ?? null;
}

export const requireAuth: RequestHandler = (
  req: Request,
  res: Response,
  next: NextFunction,
) => {
  if (!getRequestUserId(req)) {
    res.status(401).json({ error: "Войдите в аккаунт, чтобы продолжить." });
    return;
  }
  next();
};

export const requireAppUser: RequestHandler = async (
  req: Request,
  res: Response,
  next: NextFunction,
) => {
  const userId = getRequestUserId(req);
  if (!userId) {
    res.status(401).json({ error: "Войдите в аккаунт, чтобы продолжить." });
    return;
  }

  const [user] = await db
    .select()
    .from(appUsersTable)
    .where(eq(appUsersTable.clerkUserId, userId))
    .limit(1);

  if (!user) {
    res.status(409).json({
      error: "Профиль не настроен. Повторите вход или регистрацию.",
    });
    return;
  }
  if (user.isBlocked) {
    res.status(403).json({ error: "Доступ к аккаунту ограничен." });
    return;
  }

  res.locals.appUser = user;
  next();
};

export const requireAdmin: RequestHandler = (
  _req: Request,
  res: Response,
  next: NextFunction,
) => {
  const user = res.locals.appUser as AppUser | undefined;
  if (user?.role !== "admin") {
    res.status(403).json({ error: "Недостаточно прав для этого действия." });
    return;
  }
  next();
};

export const requireSeller: RequestHandler = (
  _req: Request,
  res: Response,
  next: NextFunction,
) => {
  const user = res.locals.appUser as AppUser | undefined;
  if (user?.role !== "seller") {
    res.status(403).json({ error: "Для этого действия нужен аккаунт продавца." });
    return;
  }
  next();
};
