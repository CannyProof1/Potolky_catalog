import { integer, pgTable, timestamp, varchar } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

export const adminBootstrapTable = pgTable("admin_bootstrap", {
  id: integer("id").primaryKey(),
  claimedUserId: varchar("claimed_user_id", { length: 255 }).unique(),
  claimedAt: timestamp("claimed_at", { withTimezone: true }),
});

export const insertAdminBootstrapSchema = createInsertSchema(
  adminBootstrapTable,
);
export type InsertAdminBootstrap = z.infer<typeof insertAdminBootstrapSchema>;
export type AdminBootstrap = typeof adminBootstrapTable.$inferSelect;
