import {
  jsonb,
  pgTable,
  text,
  timestamp,
  uuid,
  varchar,
} from "drizzle-orm/pg-core";

export type OrderRequestItemSnapshot = {
  productHandle: string;
  productTitle: string;
  variantId: string;
  variantTitle: string;
  quantity: number;
  unitPrice: string;
  currencyCode: string;
};

export const orderRequestsTable = pgTable("order_requests", {
  id: uuid("id").defaultRandom().primaryKey(),
  customerName: varchar("customer_name", { length: 100 }).notNull(),
  customerContact: varchar("customer_contact", { length: 200 }).notNull(),
  message: text("message"),
  items: jsonb("items").$type<OrderRequestItemSnapshot[]>().notNull(),
  status: varchar("status", { length: 20 }).notNull().default("new"),
  privacyConsentAt: timestamp("privacy_consent_at", {
    withTimezone: true,
  }).notNull().defaultNow(),
  createdAt: timestamp("created_at", { withTimezone: true })
    .notNull()
    .defaultNow(),
});

export type OrderRequest = typeof orderRequestsTable.$inferSelect;
