import {
  index,
  numeric,
  pgTable,
  text,
  timestamp,
  uuid,
  varchar,
} from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";
import { appUsersTable } from "./appUsers";

export const sellerProductsTable = pgTable(
  "seller_products",
  {
    id: uuid("id").defaultRandom().primaryKey(),
    handle: varchar("handle", { length: 255 }).notNull().unique(),
    sellerId: varchar("seller_id", { length: 255 })
      .notNull()
      .references(() => appUsersTable.clerkUserId),
    title: varchar("title", { length: 200 }).notNull(),
    description: text("description").notNull(),
    price: numeric("price", { precision: 12, scale: 2 }).notNull(),
    category: varchar("category", { length: 80 }).notNull(),
    material: varchar("material", { length: 80 }).notNull(),
    texture: varchar("texture", { length: 80 }).notNull().default(""),
    color: varchar("color", { length: 80 }).notNull().default(""),
    size: varchar("size", { length: 80 }).notNull().default(""),
    imageUrl: varchar("image_url", { length: 2000 }),
    status: varchar("status", { length: 20 }).notNull().default("pending"),
    adminNote: text("admin_note"),
    createdAt: timestamp("created_at", { withTimezone: true })
      .notNull()
      .defaultNow(),
    updatedAt: timestamp("updated_at", { withTimezone: true })
      .notNull()
      .defaultNow()
      .$onUpdate(() => new Date()),
  },
  (table) => ({
    sellerStatusIndex: index("seller_products_seller_status_idx").on(
      table.sellerId,
      table.status,
    ),
  }),
);

export const insertSellerProductSchema = createInsertSchema(
  sellerProductsTable,
).omit({
  id: true,
  handle: true,
  status: true,
  adminNote: true,
  createdAt: true,
  updatedAt: true,
});

export type InsertSellerProduct = z.infer<typeof insertSellerProductSchema>;
export type SellerProduct = typeof sellerProductsTable.$inferSelect;
